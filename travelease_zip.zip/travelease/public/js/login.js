document.addEventListener('DOMContentLoaded', function() {
    // Check if there are redirect parameters in the URL
    const urlParams = new URLSearchParams(window.location.search);
    const redirect = urlParams.get('redirect');
    const destination = urlParams.get('destination');
    
    document.getElementById('loginBtn').addEventListener('click', async (event) => {
        event.preventDefault(); // Stop form from reloading

        const username = document.getElementById('login-username').value;
        const password = document.getElementById('login-password').value;

        try {
            const res = await fetch('http://localhost:3000/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            const data = await res.json();

            if (data.user) {
                alert(`✅ Welcome back, ${data.user.username}!`);
                localStorage.setItem('user', JSON.stringify(data.user));
                
                // Check if we need to redirect to booking
                if (redirect === 'book' && destination) {
                    window.location.href = `book.html?destination=${encodeURIComponent(destination)}`;
                } else {
                    window.location.href = 'profile.html';
                }
            } else {
                alert(`❌ ${data.error}`);
            }
        } catch (error) {
            console.error('Login error:', error);
            alert('❌ Error connecting to the server. Please try again later.');
        }
    });
});