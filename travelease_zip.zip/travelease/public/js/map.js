// map.js

const map = L.map('map').setView([0, 0], 2); // Default global view

// Set up the tile layer
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: 'Map data © <a href="https://openstreetmap.org">OpenStreetMap</a> contributors'
}).addTo(map);

// Try to get the user's location
if (navigator.geolocation) {
  navigator.geolocation.getCurrentPosition(
    position => {
      const lat = position.coords.latitude;
      const lon = position.coords.longitude;
      map.setView([lat, lon], 6);
      L.marker([lat, lon]).addTo(map)
        .bindPopup("You are here!").openPopup();
    },
    () => alert("Location access denied or unavailable.")
  );
} else {
  alert("Geolocation is not supported by your browser.");
}

// Add static destination markers
const destinations = [
  { name: "Santorini", coords: [36.3932, 25.4615] },
  { name: "Kyoto", coords: [35.0116, 135.7681] },
  { name: "Paris", coords: [48.8566, 2.3522] },
  { name: "Cairo", coords: [30.0444, 31.2357] },
  { name: "Bali", coords: [-8.3405, 115.0920] },
  { name: "Rome", coords: [41.9028, 12.4964] }
];

destinations.forEach(dest => {
  L.marker(dest.coords)
    .addTo(map)
    .bindPopup(`<b>${dest.name}</b>`);
});
