// places.js - Updated to fetch destinations from database and improve layout

let allDestinations = []; // Will store destinations fetched from the server
const container = document.getElementById("allDestinations");
const searchInput = document.getElementById("searchInput");

// Fetch all destinations when the page loads
document.addEventListener('DOMContentLoaded', function() {
  fetchDestinations();
  
  // Add event listener for search
  if (searchInput) {
    searchInput.addEventListener("input", handleSearch);
  }
});

// Fetch destinations from the API
function fetchDestinations() {
  if (!container) return;
  
  // Show loading state
  container.innerHTML = '<div style="text-align: center; grid-column: 1 / -1;"><p>Loading destinations...</p></div>';
  
  fetch('http://localhost:3000/api/destinations')
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(destinations => {
      allDestinations = destinations; // Store for filtering later
      displayDestinations(destinations);
    })
    .catch(error => {
      console.error('Error fetching destinations:', error);
      container.innerHTML = '<div style="text-align: center; grid-column: 1 / -1;"><p>Failed to load destinations. Please try again later.</p></div>';
    });
}

// Display destinations in the container
function displayDestinations(destinations) {
  if (!container) return;
  
  container.innerHTML = "";
  
  if (destinations.length === 0) {
    container.innerHTML = '<div style="text-align: center; grid-column: 1 / -1;"><p>No destinations found matching your search.</p></div>';
    return;
  }
  
  destinations.forEach(place => {
    const card = document.createElement("div");
    card.className = "destination-card";
    card.innerHTML = `
      <a href="place_detail.html?name=${encodeURIComponent(place.name)}">
        <img src="${place.image_url}" alt="${place.name}" />
        <div class="card-content">
          <h4>${place.name}</h4>
          <p>From $${place.price}</p>
        </div>
      </a>
    `;
    container.appendChild(card);
  });
}

// Handle search input
function handleSearch() {
  const searchTerm = searchInput.value.toLowerCase();
  const filtered = allDestinations.filter(place =>
    place.name.toLowerCase().includes(searchTerm)
  );
  displayDestinations(filtered);
}