// main.js - Updated to fetch destinations from the database

document.addEventListener('DOMContentLoaded', function() {
  // Fetch featured destinations for the homepage
  fetchFeaturedDestinations();

  // Add event listener for the chat
  const sendButton = document.querySelector('.user-input button');
  if (sendButton) {
    sendButton.addEventListener('click', handleUserInput);
  }

  const userInput = document.getElementById('userInput');
  if (userInput) {
    userInput.addEventListener('keypress', function(event) {
      if (event.key === 'Enter') {
        handleUserInput();
      }
    });
  }
});

// Fetch featured destinations from the API
function fetchFeaturedDestinations() {
  const grid = document.getElementById("destinationGrid");
  
  // Check if the grid exists on this page
  if (!grid) return;
  
  // Show loading state
  grid.innerHTML = '<p>Loading featured destinations...</p>';
  
  fetch('http://localhost:3000/api/destinations/featured')
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.json();
    })
    .then(destinations => {
      grid.innerHTML = ''; // Clear the grid
      
      // Add each destination to the grid
      destinations.forEach(place => {
        const card = document.createElement("div");
        card.className = "destination-card";
        card.innerHTML = `
          <a href="place_detail.html?name=${encodeURIComponent(place.name)}">
            <img src="${place.image_url}" alt="${place.name}" />
            <h4>${place.name}</h4>
            <p>From $${place.price}</p>
          </a>
        `;
        grid.appendChild(card);
      });
    })
    .catch(error => {
      console.error('Error fetching destinations:', error);
      grid.innerHTML = '<p>Failed to load destinations. Please try again later.</p>';
    });
}

function handleUserInput() {
  const input = document.getElementById("userInput");
  if (!input) return;
  
  const userMessage = input.value.trim();
  if (userMessage === '') return;
  
  const chatBox = document.getElementById("chatBox");
  
  // Add user message to chat
  const userMsg = document.createElement('div');
  userMsg.className = 'message user';
  userMsg.textContent = userMessage;
  chatBox.appendChild(userMsg);
  
  // Generate bot response based on user input
  let botResponse = '';
  
  if (userMessage.toLowerCase().includes('budget') || 
      userMessage.toLowerCase().includes('$') ||
      userMessage.toLowerCase().includes('cost')) {
    
    const budgetMatch = userMessage.match(/\$\d+|\d+\s*dollars?/i);
    let budgetAmount = 0;
    
    if (budgetMatch) {
      // Extract budget amount from message
      budgetAmount = parseInt(budgetMatch[0].replace(/[^\d]/g, ''));
      botResponse = `Looking for vacations under $${budgetAmount}. Let me recommend some options! You can check out our destinations page for options that match your budget.`;
    } else {
      botResponse = `I'd be happy to help you find destinations within your budget. Can you specify your budget amount? For example, "$800" or "1000 dollars".`;
    }
  } else if (userMessage.toLowerCase().includes('hello') || 
             userMessage.toLowerCase().includes('hi') || 
             userMessage.toLowerCase().includes('hey')) {
    botResponse = 'Hello! I\'m your travel assistant. I can help you find destinations based on your budget. Just let me know how much you\'d like to spend!';
  } else {
    botResponse = `Thanks for your message! To help you find the perfect vacation package, could you share your travel budget?`;
  }
  
  // Add bot response to chat
  const botMsg = document.createElement('div');
  botMsg.className = 'message bot';
  botMsg.textContent = botResponse;
  
  // Slight delay to mimic typing
  setTimeout(() => {
    chatBox.appendChild(botMsg);
    chatBox.scrollTop = chatBox.scrollHeight;
  }, 500);
  
  // Clear input field
  input.value = '';
  
  // Scroll to the bottom of chat
  chatBox.scrollTop = chatBox.scrollHeight;
}