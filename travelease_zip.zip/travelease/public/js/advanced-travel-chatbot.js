// advanced-travel-chatbot.js - Advanced AI Travel Assistant

/**
 * Advanced Travel Chatbot with:
 * - Sophisticated NLP-like intent recognition
 * - Entity extraction
 * - Context memory
 * - Multi-parametric recommendation engine
 * - Sentiment analysis
 * - Fallback conversation handling
 * - Dynamic response generation
 */

// Chat states
const CHAT_STATES = {
  GREETING: 'greeting',
  ASK_BUDGET: 'ask_budget',
  ASK_LOCATION: 'ask_location',
  ASK_TRAVELERS: 'ask_travelers',
  ASK_SEASON: 'ask_season',
  ASK_DURATION: 'ask_duration',
  ASK_ACTIVITY: 'ask_activity',
  SHOW_RESULTS: 'show_results',
  DESTINATION_DETAILS: 'destination_details',
  BOOKING: 'booking',
  CUSTOM_QUERY: 'custom_query',
  FAREWELL: 'farewell'
};

// Context memory - stores all information about the conversation
let chatContext = {
  currentState: CHAT_STATES.GREETING,
  conversationHistory: [],
  userProfile: {
    loggedIn: false,
    userName: null,
    previousSearches: []
  },
  sentimentScore: 0,
  preferences: {
    budget: null,
    location: null,
    region: null,
    continent: null,
    travelers: 1,
    season: null,
    duration: null,
    activities: [],
    climate: null,
    mustHaves: [],
    dealBreakers: []
  },
  recommendations: [],
  currentDestination: null,
  fallbackAttempts: 0,
  conversationStartTime: null
};

// Global variables
let allDestinations = [];
let conversationEnded = false;
let typingIndicator;
let suggestionChips = [];

// Region and continent mappings for more intelligent location recognition
const REGION_MAPPINGS = {
  "europe": ["france", "italy", "spain", "greece", "germany", "uk", "portugal", "netherlands", "czech", "prague", "austria", "vienna", "croatia", "budapest", "hungary", "switzerland", "rome", "paris", "barcelona", "santorini", "amsterdam", "london"],
  "asia": ["japan", "china", "thailand", "vietnam", "indonesia", "bali", "india", "singapore", "malaysia", "korea", "tokyo", "kyoto", "bangkok", "hong kong", "seoul"],
  "north america": ["usa", "united states", "canada", "mexico", "caribbean", "hawaii", "new york", "vegas", "los angeles", "california", "florida", "miami", "cancun", "toronto", "vancouver"],
  "south america": ["brazil", "argentina", "peru", "colombia", "chile", "ecuador", "machu picchu", "rio", "buenos aires"],
  "africa": ["morocco", "egypt", "south africa", "kenya", "tanzania", "marrakech", "cape town", "cairo"],
  "oceania": ["australia", "new zealand", "fiji", "sydney", "melbourne", "queenstown"]
};

// Activity categories for a more sophisticated recommendation engine
const ACTIVITY_CATEGORIES = {
  "beaches": ["beach", "swimming", "sunbathing", "snorkeling", "diving", "sailing", "surfing", "coastal"],
  "nature": ["hiking", "mountains", "forest", "nature", "wildlife", "national park", "landscape", "scenery", "outdoor", "trekking"],
  "culture": ["museum", "history", "architecture", "art", "heritage", "temple", "church", "castle", "monument", "historic"],
  "food": ["culinary", "dining", "restaurant", "food", "eating", "cuisine", "wine", "gastronomy", "tasting", "cooking"],
  "adventure": ["adventure", "extreme", "adrenaline", "climbing", "rafting", "bungee", "skydiving", "zip-line", "kayaking"],
  "relaxation": ["relaxation", "spa", "wellness", "retreat", "peaceful", "quiet", "meditation", "yoga", "tranquil"],
  "nightlife": ["nightlife", "party", "club", "bar", "entertainment", "dancing", "music", "festival"],
  "shopping": ["shopping", "market", "mall", "boutique", "souvenir", "fashion", "retail"]
};

// Climate zones for better season-based recommendations
const CLIMATE_ZONES = {
  "tropical": ["caribbean", "southeast asia", "central america", "bali", "hawaii", "fiji", "thailand", "philippines"],
  "mediterranean": ["italy", "greece", "spain", "france", "croatia", "portugal", "turkey"],
  "desert": ["egypt", "dubai", "morocco", "arizona", "nevada", "sahara"],
  "alpine": ["switzerland", "austria", "canada", "new zealand alps", "colorado"],
  "northern": ["scandinavia", "iceland", "finland", "norway", "sweden", "russia"]
};

// Season to month mapping
const SEASON_TO_MONTHS = {
  "spring": [3, 4, 5],  // March, April, May
  "summer": [6, 7, 8],  // June, July, August
  "fall": [9, 10, 11],  // September, October, November
  "autumn": [9, 10, 11], // Same as fall
  "winter": [12, 1, 2]  // December, January, February
};

// Initialize the chat
document.addEventListener('DOMContentLoaded', () => {
  // Initialize DOM elements
  const chatBox = document.getElementById('chatBox');
  const userInput = document.getElementById('userInput');
  const sendButton = document.getElementById('sendButton');
  typingIndicator = document.getElementById('typingIndicator');
  const suggestionContainer = document.createElement('div');
  suggestionContainer.className = 'suggestion-chips';
  chatBox.parentNode.insertBefore(suggestionContainer, userInput.parentNode);
  
  // Check login status
  const user = JSON.parse(localStorage.getItem('user'));
  if (user) {
    chatContext.userProfile.loggedIn = true;
    chatContext.userProfile.userName = user.username;
  }
  
  // Record conversation start time
  chatContext.conversationStartTime = new Date();
  
  // Fetch destinations from the API for recommendations
  fetchDestinations();
  
  // Add event listeners
  if (sendButton) {
    sendButton.addEventListener('click', () => processUserInput());
  }
  
  if (userInput) {
    userInput.addEventListener('keypress', (event) => {
      if (event.key === 'Enter') {
        processUserInput();
      }
    });
    
    // Add input listener for real-time typing analysis
    userInput.addEventListener('input', analyzeUserTyping);
  }
  
  // Start conversation with greeting
  setTimeout(() => {
    const greeting = generateGreeting();
    addBotMessage(greeting);
    
    // Add initial suggestion chips
    updateSuggestions(['Yes, help me find a destination', 'Show popular destinations', 'Tell me about Eazy Travel']);
  }, 500);
});

/**
 * Generates a personalized greeting based on time of day and user status
 */
function generateGreeting() {
  const hour = new Date().getHours();
  let timeGreeting = "Hello";
  
  if (hour < 12) timeGreeting = "Good morning";
  else if (hour < 18) timeGreeting = "Good afternoon";
  else timeGreeting = "Good evening";
  
  if (chatContext.userProfile.loggedIn) {
    return `${timeGreeting}, ${chatContext.userProfile.userName}! 👋 Welcome back to Eazy Travel. I'm your travel assistant. How can I help with your travel plans today?`;
  } else {
    return `${timeGreeting}! 👋 I'm your Eazy Travel assistant. I can help you find the perfect vacation based on your preferences. Would you like to find a destination or learn about our services?`;
  }
}

/**
 * Fetches destinations from the API with error handling and retry
 */
function fetchDestinations() {
  const maxRetries = 3;
  let retryCount = 0;
  
  function attemptFetch() {
    fetch('http://localhost:3000/api/destinations')
      .then(response => {
        if (!response.ok) {
          throw new Error(`Network response was not ok: ${response.status}`);
        }
        return response.json();
      })
      .then(destinations => {
        allDestinations = destinations;
        console.log(`Loaded ${destinations.length} destinations for recommendations`);
        // Pre-process destinations for faster filtering
        preprocessDestinations();
      })
      .catch(error => {
        console.error('Error fetching destinations:', error);
        retryCount++;
        if (retryCount < maxRetries) {
          console.log(`Retrying fetch (${retryCount}/${maxRetries})...`);
          setTimeout(attemptFetch, 1000 * retryCount); // Exponential backoff
        } else {
          // If all retries fail, use fallback destinations
          console.log('Using fallback destination data');
          useFallbackDestinations();
        }
      });
  }
  
  attemptFetch();
}

/**
 * Pre-processes destinations to add additional metadata for better filtering
 */
function preprocessDestinations() {
  allDestinations.forEach(dest => {
    // Extract region and continent information
    for (const [region, keywords] of Object.entries(REGION_MAPPINGS)) {
      if (keywords.some(keyword => 
        dest.name.toLowerCase().includes(keyword) || 
        dest.description.toLowerCase().includes(keyword))) {
        dest.region = region;
        break;
      }
    }
    
    // Extract activity categories
    dest.activityCategories = [];
    for (const [category, keywords] of Object.entries(ACTIVITY_CATEGORIES)) {
      if (keywords.some(keyword => dest.description.toLowerCase().includes(keyword))) {
        dest.activityCategories.push(category);
      }
    }
    
    // Determine climate zone
    for (const [climate, locations] of Object.entries(CLIMATE_ZONES)) {
      if (locations.some(location => 
        dest.name.toLowerCase().includes(location) || 
        dest.description.toLowerCase().includes(location))) {
        dest.climate = climate;
        break;
      }
    }
    
    // Calculate a "popularity score" based on description length and price
    // Lower price and longer description = more popular in this simple model
    const descriptionScore = Math.min(dest.description.length / 50, 10);
    const priceScore = Math.max(10 - (dest.price / 200), 0);
    dest.popularityScore = descriptionScore + priceScore;
  });
}

/**
 * Uses fallback destination data when API fails
 */
function useFallbackDestinations() {
  // Simplified fallback data
  allDestinations = [
    {
      name: "Paris, France",
      price: 999,
      description: "Experience the city of love with its Eiffel Tower, cafés, and romantic streets.",
      region: "europe",
      activityCategories: ["culture", "food"],
      climate: "mediterranean",
      popularityScore: 9.5
    },
    {
      name: "Bali, Indonesia",
      price: 849,
      description: "Relax on tropical beaches, visit temples, and enjoy lush jungles.",
      region: "asia",
      activityCategories: ["beaches", "nature", "relaxation"],
      climate: "tropical",
      popularityScore: 9.2
    },
    {
      name: "New York City, USA",
      price: 1199,
      description: "Explore the city that never sleeps with its iconic skyline, Central Park, Broadway shows, and diverse neighborhoods.",
      region: "north america",
      activityCategories: ["culture", "shopping", "nightlife"],
      climate: "northern",
      popularityScore: 8.9
    }
  ];
}

/**
 * Main function to process user input based on the current state
 */
function processUserInput() {
  const userInputElement = document.getElementById('userInput');
  if (!userInputElement) return;
  
  const message = userInputElement.value.trim();
  if (message === '') return;
  
  // Add user message to chat
  addUserMessage(message);
  
  // Clear input field
  userInputElement.value = '';
  
  // Remove suggestion chips when user starts typing
  updateSuggestions([]);
  
  // Store message in conversation history
  chatContext.conversationHistory.push({
    sender: 'user',
    message: message,
    timestamp: new Date()
  });
  
  // Check for global commands that work in any state
  if (handleGlobalCommands(message)) {
    return;
  }
  
  // Show typing indicator
  showTypingIndicator();
  
  // Process message based on NLU intent detection instead of just state
  setTimeout(() => {
    // Extract entities and intents
    const entities = extractEntities(message);
    const intent = determineIntent(message, entities);
    
    // Update user sentiment
    updateSentiment(message);
    
    handleResponse(message, intent, entities);
  }, calculateResponseDelay(message));
}

/**
 * Handles global commands that work in any state
 * @param {string} message - The user's message
 * @returns {boolean} - True if a global command was handled
 */
function handleGlobalCommands(message) {
  const lowerMessage = message.toLowerCase();
  
  // Handle restart command
  if (lowerMessage === 'restart' || lowerMessage === 'start over') {
    resetContext();
    addBotMessage("Let's start fresh! How can I help with your travel plans today?");
    updateSuggestions(['Find a destination', 'View popular places', 'About Eazy Travel']);
    return true;
  }
  
  // Handle help command
  if (lowerMessage === 'help' || lowerMessage === 'commands') {
    addBotMessage("Here's how I can help you:<br><br>" +
      "- Find destinations based on your preferences<br>" +
      "- Provide details about specific places<br>" +
      "- Help you book your perfect trip<br>" +
      "- Answer questions about travel<br><br>" +
      "You can also type 'restart' anytime to start over, or 'exit' to end our conversation.");
    return true;
  }
  
  // Handle exit command
  if (lowerMessage === 'exit' || lowerMessage === 'goodbye' || lowerMessage === 'bye') {
    addBotMessage("Thank you for chatting with Eazy Travel! If you need assistance later, I'll be here to help. Safe travels! 🌍✈️");
    conversationEnded = true;
    return true;
  }
  
  return false;
}

/**
 * Extracts entities (budget, location, dates, activities) from user message
 * @param {string} message - The user's message
 * @returns {object} - Extracted entities
 */
function extractEntities(message) {
  const lowerMessage = message.toLowerCase();
  const entities = {
    budget: null,
    locations: [],
    dates: [],
    activities: [],
    travelers: null,
    duration: null
  };
  
  // Extract budget
  const budgetPatterns = [
    /\$\s*(\d+(?:\.\d+)?)\s*(?:-|to|~)\s*\$?\s*(\d+(?:\.\d+)?)/i, // $500-$1000 format
    /(\d+(?:\.\d+)?)\s*(?:to|-|~)\s*(\d+(?:\.\d+)?)\s*dollars/i, // 500 to 1000 dollars
    /under\s*\$?\s*(\d+(?:\.\d+)?)/i, // under $500
    /less than\s*\$?\s*(\d+(?:\.\d+)?)/i, // less than $500
    /around\s*\$?\s*(\d+(?:\.\d+)?)/i, // around $500
    /about\s*\$?\s*(\d+(?:\.\d+)?)/i, // about $500
    /\$\s*(\d+(?:\.\d+)?)/i // $500
  ];
  
  for (const pattern of budgetPatterns) {
    const match = lowerMessage.match(pattern);
    if (match) {
      if (match[2]) { // Range match (e.g., $500-$1000)
        entities.budget = {
          min: parseFloat(match[1]),
          max: parseFloat(match[2]),
          exact: false
        };
      } else { // Single value match
        const value = parseFloat(match[1]);
        if (lowerMessage.includes('under') || lowerMessage.includes('less than')) {
          entities.budget = {
            min: 0,
            max: value,
            exact: false
          };
        } else if (lowerMessage.includes('around') || lowerMessage.includes('about')) {
          entities.budget = {
            min: value * 0.8,
            max: value * 1.2,
            exact: false
          };
        } else {
          entities.budget = {
            min: value,
            max: value,
            exact: true
          };
        }
      }
      break;
    }
  }
  
  // Extract locations
  for (const [region, keywords] of Object.entries(REGION_MAPPINGS)) {
    for (const keyword of keywords) {
      if (lowerMessage.includes(keyword)) {
        entities.locations.push({
          name: keyword,
          type: 'location',
          region: region
        });
      }
    }
  }
  
  // Extract dates and seasons
  const months = [
    'january', 'february', 'march', 'april', 'may', 'june', 
    'july', 'august', 'september', 'october', 'november', 'december'
  ];
  
  const seasons = ['spring', 'summer', 'fall', 'autumn', 'winter'];
  
  months.forEach((month, index) => {
    if (lowerMessage.includes(month)) {
      entities.dates.push({
        type: 'month',
        value: month,
        monthNumber: index + 1
      });
    }
  });
  
  seasons.forEach(season => {
    if (lowerMessage.includes(season)) {
      entities.dates.push({
        type: 'season',
        value: season
      });
    }
  });
  
  // Extract number of travelers
  const travelerPatterns = [
    /(\d+)\s*(?:people|person|travelers|travellers|adults|guests)/i,
    /(?:we are|there are|for)\s*(\d+)/i,
    /(?:me and|with)\s*(\d+)/i,
    /family of\s*(\d+)/i
  ];
  
  for (const pattern of travelerPatterns) {
    const match = lowerMessage.match(pattern);
    if (match) {
      entities.travelers = parseInt(match[1]);
      break;
    }
  }
  
  // Extract trip duration
  const durationPatterns = [
    /(\d+)\s*(?:days|day)/i,
    /(\d+)\s*(?:weeks|week)/i,
    /(\d+)-day/i,
    /(\d+)-week/i,
    /for\s*(\d+)\s*(?:days|day|weeks|week)/i
  ];
  
  for (const pattern of durationPatterns) {
    const match = lowerMessage.match(pattern);
    if (match) {
      let duration = parseInt(match[1]);
      if (lowerMessage.includes('week')) {
        duration *= 7; // Convert weeks to days
      }
      entities.duration = duration;
      break;
    }
  }
  
  // Extract activities
  for (const [category, keywords] of Object.entries(ACTIVITY_CATEGORIES)) {
    for (const keyword of keywords) {
      if (lowerMessage.includes(keyword)) {
        entities.activities.push({
          name: keyword,
          category: category
        });
      }
    }
  }
  
  return entities;
}

/**
 * Determines user intent from message and entities
 * @param {string} message - The user's message
 * @param {object} entities - Extracted entities
 * @returns {string} - Determined intent
 */
function determineIntent(message, entities) {
  const lowerMessage = message.toLowerCase();
  
  // Check for specific intents
  if (/^(yes|yeah|sure|ok|okay|yes please|yep|yup)/i.test(lowerMessage)) {
    return 'affirmative';
  }
  
  if (/^(no|nope|not|no thanks|negative)/i.test(lowerMessage)) {
    return 'negative';
  }
  
  if (entities.budget || lowerMessage.includes('budget') || lowerMessage.includes('cost') || 
      lowerMessage.includes('price') || lowerMessage.includes('spend')) {
    return 'provide_budget';
  }
  
  if (entities.locations.length > 0 || lowerMessage.includes('location') || 
      lowerMessage.includes('where') || lowerMessage.includes('country') || 
      lowerMessage.includes('city') || lowerMessage.includes('place')) {
    return 'provide_location';
  }
  
  if (entities.dates.length > 0 || lowerMessage.includes('when') || 
      lowerMessage.includes('date') || lowerMessage.includes('month') || 
      lowerMessage.includes('season') || lowerMessage.includes('time')) {
    return 'provide_time';
  }
  
  if (entities.activities.length > 0 || lowerMessage.includes('activit') || 
      lowerMessage.includes('do there') || lowerMessage.includes('experience')) {
    return 'provide_activities';
  }
  
  if (entities.travelers || lowerMessage.includes('people') || 
      lowerMessage.includes('travelers') || lowerMessage.includes('family')) {
    return 'provide_travelers';
  }
  
  if (entities.duration || lowerMessage.includes('days') || 
      lowerMessage.includes('weeks') || lowerMessage.includes('long')) {
    return 'provide_duration';
  }
  
  if (lowerMessage.includes('recommend') || lowerMessage.includes('suggest') || 
      lowerMessage.includes('find') || lowerMessage.includes('show me')) {
    return 'request_recommendation';
  }
  
  if (/\d/.test(lowerMessage) && chatContext.currentState === CHAT_STATES.SHOW_RESULTS) {
    return 'select_result';
  }
  
  if (lowerMessage.includes('book') || lowerMessage.includes('reserve') || 
      lowerMessage.includes('purchase') || lowerMessage.includes('buy')) {
    return 'request_booking';
  }
  
  if (lowerMessage.includes('details') || lowerMessage.includes('more info') || 
      lowerMessage.includes('tell me about') || lowerMessage.includes('what about')) {
    return 'request_details';
  }
  
  // If no specific intent is found, try to match the current state
  switch (chatContext.currentState) {
    case CHAT_STATES.GREETING:
      return 'greeting';
    case CHAT_STATES.ASK_BUDGET:
      return 'provide_budget';
    case CHAT_STATES.ASK_LOCATION:
      return 'provide_location';
    case CHAT_STATES.ASK_TRAVELERS:
      return 'provide_travelers';
    case CHAT_STATES.ASK_SEASON:
      return 'provide_time';
    case CHAT_STATES.ASK_DURATION:
      return 'provide_duration';
    case CHAT_STATES.ASK_ACTIVITY:
      return 'provide_activities';
    case CHAT_STATES.SHOW_RESULTS:
      return 'select_result';
    case CHAT_STATES.DESTINATION_DETAILS:
      return 'destination_feedback';
    case CHAT_STATES.BOOKING:
      return 'booking_response';
    default:
      return 'general_query';
  }
}

/**
 * Handles the response based on intent and current state
 * @param {string} message - The user's message
 * @param {string} intent - Determined intent
 * @param {object} entities - Extracted entities
 */
function handleResponse(message, intent, entities) {
  console.log(`Handling intent: ${intent} in state: ${chatContext.currentState}`);
  
  // Handle intents based on current state
  switch (chatContext.currentState) {
    case CHAT_STATES.GREETING:
      handleGreetingState(message, intent, entities);
      break;
    case CHAT_STATES.ASK_BUDGET:
      handleBudgetState(message, intent, entities);
      break;
    case CHAT_STATES.ASK_LOCATION:
      handleLocationState(message, intent, entities);
      break;
    case CHAT_STATES.ASK_TRAVELERS:
      handleTravelersState(message, intent, entities);
      break;
    case CHAT_STATES.ASK_SEASON:
      handleSeasonState(message, intent, entities);
      break;
    case CHAT_STATES.ASK_DURATION:
      handleDurationState(message, intent, entities);
      break;
    case CHAT_STATES.ASK_ACTIVITY:
      handleActivityState(message, intent, entities);
      break;
    case CHAT_STATES.SHOW_RESULTS:
      handleResultsState(message, intent, entities);
      break;
    case CHAT_STATES.DESTINATION_DETAILS:
      handleDestinationDetailsState(message, intent, entities);
      break;
    case CHAT_STATES.BOOKING:
      handleBookingState(message, intent, entities);
      break;
    case CHAT_STATES.CUSTOM_QUERY:
      handleCustomQueryState(message, intent, entities);
      break;
    case CHAT_STATES.FAREWELL:
      handleFarewellState(message, intent, entities);
      break;
  }
  
  // Store bot's response in conversation history
  const lastBotMessage = document.querySelector('.message.bot:last-child');
  if (lastBotMessage) {
    chatContext.conversationHistory.push({
      sender: 'bot',
      message: lastBotMessage.innerHTML,
      timestamp: new Date()
    });
  }
}

/* State handlers */

function handleGreetingState(message, intent, entities) {
  const positiveResponse = intent === 'affirmative' || intent === 'request_recommendation';
  
  // If budget already provided, skip to next state
  if (intent === 'provide_budget' && entities.budget) {
    updateBudgetPreference(entities.budget);
    chatContext.currentState = CHAT_STATES.ASK_LOCATION;
    
    addBotMessage(`Great! I'll help you find destinations within your budget of ${formatBudget(entities.budget)}. Do you have a specific region or country in mind?`);
    updateSuggestions(['Europe', 'Asia', 'Caribbean', 'Anywhere']);
    return;
  }
  
  if (positiveResponse) {
    chatContext.currentState = CHAT_STATES.ASK_BUDGET;
    
    addBotMessage("Great! Let's find you an amazing destination. What's your budget range for this trip? (e.g. under $500, $500-$1000, over $1000)");
    updateSuggestions(['Under $500', '$500-$1000', 'Over $1000', 'No specific budget']);
  } else if (intent === 'negative') {
    chatContext.currentState = CHAT_STATES.CUSTOM_QUERY;
    
    addBotMessage("No problem! I'm here to help with any travel-related questions. What would you like to know about?");
    updateSuggestions(['Popular destinations', 'Travel tips', 'Best time to travel', 'About Eazy Travel']);
  } else {
    // Try to determine if there's a different specific request
    if (intent === 'provide_location') {
      chatContext.currentState = CHAT_STATES.ASK_BUDGET;
      updateLocationPreference(entities.locations);
      
      addBotMessage(`I see you're interested in ${formatLocations(entities.locations)}! Let's first establish your budget. What's your budget range for this trip?`);
      updateSuggestions(['Under $500', '$500-$1000', 'Over $1000', 'No specific budget']);
    } else if (intent === 'provide_activities') {
      chatContext.currentState = CHAT_STATES.ASK_BUDGET;
      updateActivityPreferences(entities.activities);
      
      addBotMessage(`Great! I'll find destinations with ${formatActivities(entities.activities)}. First, what's your budget range for this trip?`);
      updateSuggestions(['Under $500', '$500-$1000', 'Over $1000', 'No specific budget']);
    } else {
      // General fallback
      addBotMessage("I'd be happy to help you find the perfect vacation destination. Would you like me to recommend places based on your preferences?");
      updateSuggestions(['Yes, please', 'Show me popular places', 'I have a specific question']);
    }
  }
}

function handleBudgetState(message, intent, entities) {
  if (intent === 'provide_budget' && entities.budget) {
    updateBudgetPreference(entities.budget);
    chatContext.currentState = CHAT_STATES.ASK_LOCATION;
    
    addBotMessage(`Thanks for sharing your budget of ${formatBudget(entities.budget)}. Now, do you have a specific region or country in mind for your trip?`);
    updateSuggestions(['Europe', 'Asia', 'Caribbean', 'Anywhere']);
  } else if (message.toLowerCase().includes('no budget') || 
             message.toLowerCase().includes('doesn\'t matter') || 
             message.toLowerCase().includes('any budget')) {
    // Set a high default budget
    updateBudgetPreference({min: 0, max: 5000, exact: false});
    chatContext.currentState = CHAT_STATES.ASK_LOCATION;
    
    addBotMessage("I understand that budget isn't a constraint for you. That opens up many exciting possibilities! Do you have a specific region or country in mind?");
    updateSuggestions(['Europe', 'Asia', 'Caribbean', 'Anywhere']);
  } else {
    // Try to extract a number if regular patterns failed
    const numbers = message.match(/\d+/g);
    if (numbers && numbers.length > 0) {
      const budget = {
        min: parseInt(numbers[0]),
        max: numbers.length > 1 ? parseInt(numbers[1]) : parseInt(numbers[0]) * 1.5,
        exact: false
      };
      
      updateBudgetPreference(budget);
      chatContext.currentState = CHAT_STATES.ASK_LOCATION;
      
      addBotMessage(`I'll search for options around ${formatBudget(budget)}. Do you have a specific region or country in mind for your trip?`);
      updateSuggestions(['Europe', 'Asia', 'Caribbean', 'Anywhere']);
    } else {
      // Still couldn't determine budget
      chatContext.fallbackAttempts++;
      
      if (chatContext.fallbackAttempts > 2) {
        // After multiple failures, set a default budget
        // After multiple failures, set a default budget
        updateBudgetPreference({min: 500, max: 1500, exact: false});
        chatContext.currentState = CHAT_STATES.ASK_LOCATION;
        
        addBotMessage("I'll use a typical vacation budget range of $500-$1500 for now. We can always refine this later. Do you have a specific region or country in mind for your trip?");
        updateSuggestions(['Europe', 'Asia', 'Caribbean', 'Anywhere']);
      } else {
        addBotMessage("I'm having trouble understanding your budget. Could you provide a number or range? For example, \"$800\" or \"between $500 and $1000\".");
        updateSuggestions(['Under $500', '$500-$1000', 'Over $1000', 'No specific budget']);
      }
    }
  }
}

function handleLocationState(message, intent, entities) {
  if (intent === 'provide_location' && entities.locations.length > 0) {
    updateLocationPreference(entities.locations);
    chatContext.currentState = CHAT_STATES.ASK_TRAVELERS;
    
    addBotMessage(`${formatLocations(entities.locations)} is a great choice! How many people will be traveling? (Just you or with others?)`);
    updateSuggestions(['Just me', '2 people', 'Family of 4', 'Group of 6']);
  } else if (message.toLowerCase().includes('anywhere') || 
             message.toLowerCase().includes('any place') || 
             message.toLowerCase().includes('don\'t care') ||
             message.toLowerCase().includes('not sure')) {
    
    chatContext.preferences.location = 'anywhere';
    chatContext.currentState = CHAT_STATES.ASK_TRAVELERS;
    
    addBotMessage("I understand you're open to destinations worldwide. That gives us many exciting options! How many people will be traveling?");
    updateSuggestions(['Just me', '2 people', 'Family of 4', 'Group']);
  } else if (intent === 'provide_travelers' && entities.travelers) {
    // User skipped ahead and provided travelers info
    updateLocationPreference([{name: 'anywhere', type: 'location'}]);
    updateTravelersPreference(entities.travelers);
    chatContext.currentState = CHAT_STATES.ASK_SEASON;
    
    addBotMessage(`Got it, a trip for ${entities.travelers} ${entities.travelers === 1 ? 'person' : 'people'}. When are you planning to travel? (Month or season)`);
    updateSuggestions(['Summer', 'Winter', 'Spring', 'Fall', 'Next month']);
  } else {
    chatContext.fallbackAttempts++;
    
    if (chatContext.fallbackAttempts > 2) {
      updateLocationPreference([{name: 'anywhere', type: 'location'}]);
      chatContext.currentState = CHAT_STATES.ASK_TRAVELERS;
      
      addBotMessage("I'll keep your destination options open for now. How many people will be traveling?");
      updateSuggestions(['Just me', '2 people', 'Family of 4', 'Group']);
    } else {
      addBotMessage("I didn't catch a specific location. Could you tell me which continent, country, or region you're interested in? Or say 'anywhere' if you're flexible.");
      updateSuggestions(['Europe', 'Asia', 'North America', 'Anywhere']);
    }
  }
}

function handleTravelersState(message, intent, entities) {
  if (intent === 'provide_travelers' && entities.travelers) {
    updateTravelersPreference(entities.travelers);
    chatContext.currentState = CHAT_STATES.ASK_SEASON;
    
    addBotMessage(`Perfect, a trip for ${entities.travelers} ${entities.travelers === 1 ? 'person' : 'people'}. When are you planning to travel? (Month or season)`);
    updateSuggestions(['Summer', 'Winter', 'Spring', 'Fall', 'Next month']);
  } else if (message.toLowerCase().includes('just me') || 
             message.toLowerCase().includes('solo') || 
             message.toLowerCase().includes('myself') ||
             message.toLowerCase().includes('alone')) {
    
    updateTravelersPreference(1);
    chatContext.currentState = CHAT_STATES.ASK_SEASON;
    
    addBotMessage("Solo travel can be an amazing experience! When are you planning to travel? (Month or season)");
    updateSuggestions(['Summer', 'Winter', 'Spring', 'Fall', 'Next month']);
  } else if (message.toLowerCase().includes('couple') || 
             message.toLowerCase().includes('me and my') || 
             message.toLowerCase().includes('with my') ||
             message.toLowerCase().includes('two')) {
    
    updateTravelersPreference(2);
    chatContext.currentState = CHAT_STATES.ASK_SEASON;
    
    addBotMessage("A trip for two sounds perfect! When are you planning to travel? (Month or season)");
    updateSuggestions(['Summer', 'Winter', 'Spring', 'Fall', 'Next month']);
  } else if (message.toLowerCase().includes('family')) {
    // Estimate family size if not specified
    const familySize = entities.travelers || 4;
    updateTravelersPreference(familySize);
    chatContext.currentState = CHAT_STATES.ASK_SEASON;
    
    addBotMessage(`A family trip for ${familySize} people! When are you planning to travel? (Month or season)`);
    updateSuggestions(['Summer', 'Winter', 'Spring', 'Fall', 'During school break']);
  } else if (intent === 'provide_time' && entities.dates.length > 0) {
    // User skipped ahead and provided time info
    updateTravelersPreference(2); // Default to 2 travelers if not specified
    updateTimePreference(entities.dates);
    chatContext.currentState = CHAT_STATES.ASK_DURATION;
    
    addBotMessage(`I'll assume this is a trip for 2 people in ${formatDates(entities.dates)}. How long will your trip be? (Number of days or weeks)`);
    updateSuggestions(['Weekend', '1 week', '2 weeks', 'Longer']);
  } else {
    chatContext.fallbackAttempts++;
    
    if (chatContext.fallbackAttempts > 2) {
      updateTravelersPreference(2);
      chatContext.currentState = CHAT_STATES.ASK_SEASON;
      
      addBotMessage("I'll assume this is a trip for 2 people. When are you planning to travel? (Month or season)");
      updateSuggestions(['Summer', 'Winter', 'Spring', 'Fall', 'Next month']);
    } else {
      addBotMessage("I need to know how many people will be traveling. Could you provide a number? For example, \"just me\", \"2 people\", or \"family of 4\".");
      updateSuggestions(['Just me', '2 people', 'Family of 4', 'Group']);
    }
  }
}

function handleSeasonState(message, intent, entities) {
  if (intent === 'provide_time' && entities.dates.length > 0) {
    updateTimePreference(entities.dates);
    chatContext.currentState = CHAT_STATES.ASK_DURATION;
    
    addBotMessage(`${formatDates(entities.dates)} is a great time to travel! How long will your trip be? (Number of days or weeks)`);
    updateSuggestions(['Weekend', '1 week', '2 weeks', 'Longer']);
  } else if (message.toLowerCase().includes('soon') || 
             message.toLowerCase().includes('next month') || 
             message.toLowerCase().includes('upcoming')) {
    
    // Set to next month
    const nextMonth = new Date();
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    const monthName = nextMonth.toLocaleString('default', { month: 'long' });
    
    updateTimePreference([{
      type: 'month',
      value: monthName.toLowerCase(),
      monthNumber: nextMonth.getMonth() + 1
    }]);
    
    chatContext.currentState = CHAT_STATES.ASK_DURATION;
    
    addBotMessage(`Got it, planning for ${monthName}. How long will your trip be? (Number of days or weeks)`);
    updateSuggestions(['Weekend', '1 week', '2 weeks', 'Longer']);
  } else if (intent === 'provide_duration' && entities.duration) {
    // User skipped ahead and provided duration
    // Set a default season if none provided
    if (!chatContext.preferences.season) {
      const currentMonth = new Date().getMonth();
      let season;
      
      if (currentMonth >= 2 && currentMonth <= 4) season = 'spring';
      else if (currentMonth >= 5 && currentMonth <= 7) season = 'summer';
      else if (currentMonth >= 8 && currentMonth <= 10) season = 'fall';
      else season = 'winter';
      
      updateTimePreference([{type: 'season', value: season}]);
    }
    
    updateDurationPreference(entities.duration);
    chatContext.currentState = CHAT_STATES.ASK_ACTIVITY;
    
    addBotMessage(`I'll plan for a ${entities.duration}-day trip. What kind of activities or experiences are you interested in? (e.g., beaches, hiking, culture, food)`);
    updateSuggestions(['Beaches', 'Cultural experiences', 'Adventure', 'Relaxation']);
  } else {
    chatContext.fallbackAttempts++;
    
    if (chatContext.fallbackAttempts > 2) {
      // Set to summer as default
      updateTimePreference([{type: 'season', value: 'summer'}]);
      chatContext.currentState = CHAT_STATES.ASK_DURATION;
      
      addBotMessage("I'll assume you're planning for summer. How long will your trip be? (Number of days or weeks)");
      updateSuggestions(['Weekend', '1 week', '2 weeks', 'Longer']);
    } else {
      addBotMessage("When would you like to travel? You can specify a month (like 'July') or a season (like 'summer').");
      updateSuggestions(['Summer', 'Winter', 'Spring', 'Fall', 'Next month']);
    }
  }
}

function handleDurationState(message, intent, entities) {
  if (intent === 'provide_duration' && entities.duration) {
    updateDurationPreference(entities.duration);
    chatContext.currentState = CHAT_STATES.ASK_ACTIVITY;
    
    addBotMessage(`A ${entities.duration}-day trip sounds perfect. What kind of activities or experiences are you interested in? (e.g., beaches, hiking, culture, food)`);
    updateSuggestions(['Beaches', 'Cultural experiences', 'Adventure', 'Relaxation']);
  } else if (message.toLowerCase().includes('weekend')) {
    updateDurationPreference(3);
    chatContext.currentState = CHAT_STATES.ASK_ACTIVITY;
    
    addBotMessage("A weekend getaway it is! What kind of activities or experiences are you interested in?");
    updateSuggestions(['Beaches', 'Cultural experiences', 'Adventure', 'Relaxation']);
  } else if (message.toLowerCase().includes('week')) {
    const weeks = message.match(/(\d+)\s*week/);
    const numWeeks = weeks ? parseInt(weeks[1]) : 1;
    const days = numWeeks * 7;
    
    updateDurationPreference(days);
    chatContext.currentState = CHAT_STATES.ASK_ACTIVITY;
    
    addBotMessage(`${numWeeks} ${numWeeks === 1 ? 'week' : 'weeks'} gives you plenty of time to explore! What kind of activities or experiences are you interested in?`);
    updateSuggestions(['Beaches', 'Cultural experiences', 'Adventure', 'Relaxation']);
  } else if (intent === 'provide_activities' && entities.activities.length > 0) {
    // User skipped ahead and provided activities
    updateDurationPreference(7); // Default to 1 week
    updateActivityPreferences(entities.activities);
    
    // We have enough info to show recommendations
    chatContext.currentState = CHAT_STATES.SHOW_RESULTS;
    
    addBotMessage("I'll assume a 7-day trip. Let me find some destinations that match your preferences...");
    
    // Short delay to simulate "thinking"
    setTimeout(() => {
      showRecommendedDestinations();
    }, 1500);
  } else {
    chatContext.fallbackAttempts++;
    
    if (chatContext.fallbackAttempts > 2) {
      updateDurationPreference(7);
      chatContext.currentState = CHAT_STATES.ASK_ACTIVITY;
      
      addBotMessage("I'll plan for a standard 7-day vacation. What kind of activities or experiences are you interested in?");
      updateSuggestions(['Beaches', 'Cultural experiences', 'Adventure', 'Relaxation']);
    } else {
      addBotMessage("How long will your trip be? You can specify days (e.g., \"5 days\") or weeks (e.g., \"2 weeks\").");
      updateSuggestions(['Weekend', '1 week', '2 weeks', 'Longer']);
    }
  }
}

function handleActivityState(message, intent, entities) {
  if (intent === 'provide_activities' && entities.activities.length > 0) {
    updateActivityPreferences(entities.activities);
    chatContext.currentState = CHAT_STATES.SHOW_RESULTS;
    
    addBotMessage(`Great! I'll find destinations offering ${formatActivities(entities.activities)}. Let me search for the perfect matches based on all your preferences...`);
    
    // Short delay to simulate "thinking"
    setTimeout(() => {
      showRecommendedDestinations();
    }, 1500);
  } else if (message.toLowerCase().includes('anything') || 
             message.toLowerCase().includes('everything') || 
             message.toLowerCase().includes('not sure') ||
             message.toLowerCase().includes('all kinds')) {
    
    // Set some default popular activities
    updateActivityPreferences([
      {name: 'beach', category: 'beaches'},
      {name: 'culture', category: 'culture'},
      {name: 'food', category: 'food'}
    ]);
    
    chatContext.currentState = CHAT_STATES.SHOW_RESULTS;
    
    addBotMessage("You're open to various experiences! I'll find diverse destinations with a mix of relaxation, culture, and culinary experiences. Searching now...");
    
    // Short delay to simulate "thinking"
    setTimeout(() => {
      showRecommendedDestinations();
    }, 1500);
  } else {
    chatContext.fallbackAttempts++;
    
    if (chatContext.fallbackAttempts > 2) {
      // Set some default popular activities
      updateActivityPreferences([
        {name: 'beach', category: 'beaches'},
        {name: 'sightseeing', category: 'culture'}
      ]);
      
      chatContext.currentState = CHAT_STATES.SHOW_RESULTS;
      
      addBotMessage("I'll assume you're interested in typical vacation activities like beaches and sightseeing. Let me find some great destinations for you...");
      
      // Short delay to simulate "thinking"
      setTimeout(() => {
        showRecommendedDestinations();
      }, 1500);
    } else {
      addBotMessage("What activities or experiences would you enjoy on this trip? For example: beaches, hiking, museums, shopping, food experiences, or relaxation.");
      updateSuggestions(['Beaches', 'Cultural experiences', 'Adventure', 'Relaxation', 'Food & dining']);
    }
  }
}

function handleResultsState(message, intent, entities) {
  // Check if user mentioned a destination number
  const destinationNumber = parseInt(message.match(/\d+/)?.[0]);
  
  if (intent === 'select_result' && destinationNumber && destinationNumber <= chatContext.recommendations.length) {
    // User referenced a destination by number
    const selectedDestination = chatContext.recommendations[destinationNumber - 1];
    chatContext.currentDestination = selectedDestination;
    chatContext.currentState = CHAT_STATES.DESTINATION_DETAILS;
    
    showDestinationDetails(selectedDestination);
  } else if (intent === 'request_details') {
    // Check if user mentioned a destination by name
    const destinationName = extractDestinationName(message);
    const matchedDestination = findDestinationByName(destinationName);
    
    if (matchedDestination) {
      chatContext.currentDestination = matchedDestination;
      chatContext.currentState = CHAT_STATES.DESTINATION_DETAILS;
      
      showDestinationDetails(matchedDestination);
    } else {
      addBotMessage("I'm not sure which destination you're interested in. Could you specify by number (1, 2, 3...) or name?");
      
      // Remind user of options
      let reminderMsg = "Here are the destinations I recommended:<br>";
      chatContext.recommendations.forEach((dest, i) => {
        reminderMsg += `${i+1}. ${dest.name}<br>`;
      });
      addBotMessage(reminderMsg);
    }
  } else if (intent === 'request_recommendation') {
    // User wants different recommendations
    addBotMessage("Let me find some alternative destinations for you...");
    
    // Adjust search criteria to be more flexible
    broadenSearchCriteria();
    
    // Short delay to simulate "thinking"
    setTimeout(() => {
      showRecommendedDestinations();
    }, 1500);
  } else if (intent === 'request_booking' || intent === 'affirmative') {
    // User wants to book without specifying which destination
    if (chatContext.recommendations.length > 0) {
      chatContext.currentDestination = chatContext.recommendations[0];
      chatContext.currentState = CHAT_STATES.BOOKING;
      
      addBotMessage(`Would you like to book a trip to ${chatContext.currentDestination.name}? Or would you prefer one of the other recommendations?`);
      updateSuggestions([`Book ${chatContext.currentDestination.name}`, 'Show me more options', 'Different destination']);
    } else {
      addBotMessage("I need to find some destinations for you first. Let me search again with broader criteria...");
      
      broadenSearchCriteria();
      
      // Short delay to simulate "thinking"
      setTimeout(() => {
        showRecommendedDestinations();
      }, 1500);
    }
  } else if (intent === 'negative') {
    // User doesn't like the recommendations
    addBotMessage("I'm sorry the recommendations don't match what you're looking for. Let me try again with different criteria. What would you like to change about your preferences?");
    
    chatContext.currentState = CHAT_STATES.CUSTOM_QUERY;
    updateSuggestions(['Different budget', 'Different location', 'Different activities', 'Start over']);
  } else {
    // Check if user mentioned a destination by name
    for (const dest of chatContext.recommendations) {
      if (message.toLowerCase().includes(dest.name.toLowerCase())) {
        chatContext.currentDestination = dest;
        chatContext.currentState = CHAT_STATES.DESTINATION_DETAILS;
        
        showDestinationDetails(dest);
        return;
      }
    }
    
    // No specific destination found
    addBotMessage("I'm not sure which destination you're interested in. Could you specify by number (1, 2, 3...) or name?");
  }
}

function handleDestinationDetailsState(message, intent, entities) {
  if (intent === 'request_booking' || intent === 'affirmative') {
    chatContext.currentState = CHAT_STATES.BOOKING;
    
    const destination = chatContext.currentDestination;
    
    // Calculate estimated total cost
    const numTravelers = chatContext.preferences.travelers || 1;
    const duration = chatContext.preferences.duration || 7;
    const estimatedTotal = Math.round(destination.price * numTravelers * (duration / 7));
    
    addBotMessage(`Great choice! A ${duration}-day trip to ${destination.name} for ${numTravelers} ${numTravelers === 1 ? 'person' : 'people'} would cost approximately $${estimatedTotal}. Would you like to proceed with booking?`);
    updateSuggestions(['Yes, book now', 'Not now', 'Show more destinations']);
  } else if (intent === 'negative') {
    chatContext.currentState = CHAT_STATES.SHOW_RESULTS;
    
    addBotMessage("No problem. Would you like to see the other recommended destinations again or start a new search?");
    updateSuggestions(['Show recommendations again', 'Start new search', 'Different destination']);
  } else if (intent === 'request_recommendation') {
    chatContext.currentState = CHAT_STATES.SHOW_RESULTS;
    
    addBotMessage("Let me show you the other recommended destinations again:");
    showRecommendedDestinations();
  } else if (message.toLowerCase().includes('activities') || 
             message.toLowerCase().includes('things to do') || 
             message.toLowerCase().includes('what can i do')) {
    
    // Provide more details about activities
    showDestinationActivities(chatContext.currentDestination);
  } else if (message.toLowerCase().includes('weather') || 
             message.toLowerCase().includes('climate') || 
             message.toLowerCase().includes('temperature')) {
    
    // Provide weather information
    showDestinationWeather(chatContext.currentDestination);
  } else if (message.toLowerCase().includes('cost') || 
             message.toLowerCase().includes('price') || 
             message.toLowerCase().includes('expense')) {
    
    // Provide cost breakdown
    showDestinationCosts(chatContext.currentDestination);
  } else {
    // General inquiry about the destination
    addBotMessage(`What else would you like to know about ${chatContext.currentDestination.name}? You can ask about activities, weather, costs, or proceed with booking.`);
    updateSuggestions(['Activities', 'Weather', 'Costs', 'Book this trip']);
  }
}

function handleBookingState(message, intent, entities) {
  if (intent === 'affirmative') {
    // Check if user is logged in
    if (chatContext.userProfile.loggedIn) {
      // User is logged in, direct to booking page
      initiateBookingProcess();
    } else {
      // User is not logged in, direct to login page
      addBotMessage("To complete your booking, you'll need to log in first. Would you like me to redirect you to the login page?");
      updateSuggestions(['Yes, go to login', 'No, maybe later']);
    }
  } else if (intent === 'negative') {
    chatContext.currentState = CHAT_STATES.FAREWELL;
    
    addBotMessage("No problem! You can come back anytime to book your dream vacation. Is there anything else I can help you with today?");
    updateSuggestions(['Start new search', 'Show other destinations', 'No thanks']);
  } else if (message.toLowerCase().includes('login') || 
             message.toLowerCase().includes('sign in') || 
             message.toLowerCase().includes('account')) {
    
    redirectToLogin();
  } else if (message.toLowerCase().includes('different') || 
             message.toLowerCase().includes('other') || 
             message.toLowerCase().includes('another')) {
    
    chatContext.currentState = CHAT_STATES.SHOW_RESULTS;
    
    addBotMessage("Let me show you the other recommended destinations again:");
    showRecommendedDestinations();
  } else {
    addBotMessage(`Would you like to proceed with booking your trip to ${chatContext.currentDestination.name}? I can redirect you to complete your reservation.`);
    updateSuggestions(['Yes, continue to booking', 'No thanks', 'Show other options']);
  }
}

function handleCustomQueryState(message, intent, entities) {
  // This state handles various custom queries that don't fit the main flow
  
  if (message.toLowerCase().includes('popular destinations') || 
      message.toLowerCase().includes('top places') || 
      message.toLowerCase().includes('best destinations')) {
    
    showPopularDestinations();
  } else if (message.toLowerCase().includes('travel tips') || 
             message.toLowerCase().includes('advice') || 
             message.toLowerCase().includes('suggestions')) {
    
    showTravelTips();
  } else if (message.toLowerCase().includes('best time') || 
             message.toLowerCase().includes('when to travel') || 
             message.toLowerCase().includes('season')) {
    
    showBestTimeToTravel();
  } else if (message.toLowerCase().includes('about eazy travel') || 
             message.toLowerCase().includes('company') || 
             message.toLowerCase().includes('services')) {
    
    showAboutEazyTravel();
  } else if (intent === 'request_recommendation' || 
             message.toLowerCase().includes('find destination') || 
             message.toLowerCase().includes('search for')) {
    
    // User wants to go back to the main search flow
    resetContext();
    chatContext.currentState = CHAT_STATES.ASK_BUDGET;
    
    addBotMessage("Let's find you the perfect destination! What's your budget range for this trip?");
    updateSuggestions(['Under $500', '$500-$1000', 'Over $1000', 'No specific budget']);
  } else {
    // Try to provide a helpful response based on the query
    const response = generateCustomResponse(message);
    addBotMessage(response);
    
    // Offer to start a destination search
    setTimeout(() => {
      addBotMessage("Would you like me to help you find a specific destination based on your preferences?");
      updateSuggestions(['Yes, find a destination', 'No thanks']);
    }, 1000);
  }
}

function handleFarewellState(message, intent, entities) {
  if (intent === 'affirmative' || 
      message.toLowerCase().includes('start') || 
      message.toLowerCase().includes('new search')) {
    
    // Start over
    resetContext();
    chatContext.currentState = CHAT_STATES.GREETING;
    
    addBotMessage("Let's start fresh! What kind of trip are you looking for?");
    updateSuggestions(['Find a destination', 'View popular places', 'About Eazy Travel']);
  } else if (intent === 'negative' || 
             message.toLowerCase().includes('bye') || 
             message.toLowerCase().includes('goodbye')) {
    
    // End conversation
    addBotMessage("Thank you for chatting with Eazy Travel! Have a wonderful day and happy travels! 🌍✈️");
    conversationEnded = true;
  } else {
    addBotMessage("Is there anything else you'd like help with? I can start a new search or show you some popular destinations.");
    updateSuggestions(['Start new search', 'Popular destinations', 'No thanks']);
  }
}

/* Utility functions */

/**
 * Shows the typing indicator to simulate bot typing
 */
function showTypingIndicator() {
  if (typingIndicator) {
    typingIndicator.style.display = 'flex';
  }
}

/**
 * Hides the typing indicator
 */
function hideTypingIndicator() {
  if (typingIndicator) {
    typingIndicator.style.display = 'none';
  }
}

/**
 * Adds a message from the user to the chat
 * @param {string} message - The user's message
 */
function addUserMessage(message) {
  const chatBox = document.getElementById('chatBox');
  if (!chatBox) return;
  
  const userMsg = document.createElement('div');
  userMsg.className = 'message user';
  userMsg.textContent = message;
  chatBox.appendChild(userMsg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

/**
 * Adds a message from the bot to the chat
 * @param {string} message - The bot's message
 */
function addBotMessage(message) {
  const chatBox = document.getElementById('chatBox');
  if (!chatBox) return;
  
  // Hide typing indicator
  hideTypingIndicator();
  
  const botMsg = document.createElement('div');
  botMsg.className = 'message bot';
  botMsg.innerHTML = message;
  chatBox.appendChild(botMsg);
  chatBox.scrollTop = chatBox.scrollHeight;
}

/**
 * Calculates an appropriate response delay based on message length
 * @param {string} message - The user's message
 * @returns {number} - Delay in milliseconds
 */
function calculateResponseDelay(message) {
  // Base delay
  let delay = 500;
  
  // Add delay based on message length (simulates reading time)
  delay += Math.min(message.length * 10, 1000);
  
  // Add randomness
  delay += Math.random() * 300;
  
  return delay;
}

/**
 * Updates suggestion chips below the chat
 * @param {string[]} suggestions - Array of suggestion texts
 */
function updateSuggestions(suggestions) {
  const container = document.querySelector('.suggestion-chips');
  if (!container) return;
  
  // Clear existing suggestions
  container.innerHTML = '';
  
  // If conversation ended or no suggestions, don't show any
  if (conversationEnded || !suggestions || suggestions.length === 0) {
    container.style.display = 'none';
    return;
  }
  
  // Create chips for each suggestion
  suggestions.forEach(text => {
    const chip = document.createElement('button');
    chip.className = 'suggestion-chip';
    chip.textContent = text;
    chip.addEventListener('click', () => {
      const userInput = document.getElementById('userInput');
      if (userInput) {
        userInput.value = text;
        processUserInput();
      }
    });
    container.appendChild(chip);
  });
  
  container.style.display = 'flex';
}

/**
 * Analyzes user typing in real-time
 */
function analyzeUserTyping() {
  // This could be expanded for more sophisticated analysis
  const userInput = document.getElementById('userInput');
  if (!userInput) return;
  
  const currentInput = userInput.value.trim();
  
  // For now, just hide suggestions when user starts typing
  if (currentInput.length > 0) {
    const container = document.querySelector('.suggestion-chips');
    if (container) {
      container.style.display = 'none';
    }
  }
}

/**
 * Updates budget preference
 * @param {object} budget - Budget object with min and max values
 */
function updateBudgetPreference(budget) {
  chatContext.preferences.budget = budget;
  console.log('Updated budget preference:', budget);
  chatContext.fallbackAttempts = 0;
}

/**
 * Updates location preference
 * @param {array} locations - Array of location objects
 */
function updateLocationPreference(locations) {
  if (locations.length > 0) {
    chatContext.preferences.location = locations[0].name;
    
    // Determine region and continent
    for (const [region, keywords] of Object.entries(REGION_MAPPINGS)) {
      if (keywords.some(keyword => locations[0].name.toLowerCase().includes(keyword))) {
        chatContext.preferences.region = region;
        break;
      }
    }
  }
  
  console.log('Updated location preference:', chatContext.preferences.location);
  chatContext.fallbackAttempts = 0;
}

/**
 * Updates travelers preference
 * @param {number} travelers - Number of travelers
 */
function updateTravelersPreference(travelers) {
  chatContext.preferences.travelers = travelers;
  console.log('Updated travelers preference:', travelers);
  chatContext.fallbackAttempts = 0;
}

/**
 * Updates time preference
 * @param {array} dates - Array of date objects
 */
function updateTimePreference(dates) {
  if (dates.length > 0) {
    const date = dates[0];
    if (date.type === 'season') {
      chatContext.preferences.season = date.value;
    } else if (date.type === 'month') {
      chatContext.preferences.season = monthToSeason(date.monthNumber);
    }
  }
  
  console.log('Updated time preference:', chatContext.preferences.season);
  chatContext.fallbackAttempts = 0;
}

/**
 * Updates duration preference
 * @param {number} duration - Duration in days
 */
function updateDurationPreference(duration) {
  chatContext.preferences.duration = duration;
  console.log('Updated duration preference:', duration);
  chatContext.fallbackAttempts = 0;
}

/**
 * Updates activity preferences
 * @param {array} activities - Array of activity objects
 */
function updateActivityPreferences(activities) {
  if (activities.length > 0) {
    // Add to existing activities without duplicates
    activities.forEach(activity => {
      if (!chatContext.preferences.activities.some(a => a.name === activity.name)) {
        chatContext.preferences.activities.push(activity);
      }
    });
  }
  
  console.log('Updated activity preferences:', chatContext.preferences.activities);
  chatContext.fallbackAttempts = 0;
}

/**
 * Converts month number to season
 * @param {number} monthNumber - Month number (1-12)
 * @returns {string} - Season name
 */
function monthToSeason(monthNumber) {
  if (monthNumber >= 3 && monthNumber <= 5) return 'spring';
  if (monthNumber >= 6 && monthNumber <= 8) return 'summer';
  if (monthNumber >= 9 && monthNumber <= 11) return 'autumn';
  return 'winter';
}

/**
 * Formats budget for display
 * @param {object} budget - Budget object
 * @returns {string} - Formatted budget string
 */
function formatBudget(budget) {
  if (!budget) return 'flexible budget';
  
  if (budget.exact) {
    return `$${budget.min}`;
  } else if (budget.min === 0) {
    return `under $${budget.max}`;
  } else if (budget.min === budget.max) {
    return `$${budget.min}`;
  } else {
    return `$${budget.min}-$${budget.max}`;
  }
}

/**
 * Formats locations for display
 * @param {array} locations - Array of location objects
 * @returns {string} - Formatted locations string
 */
function formatLocations(locations) {
  if (!locations || locations.length === 0) return 'any location';
  
  if (locations.length === 1) {
    return locations[0].name;
  } else {
    const locationNames = locations.map(loc => loc.name);
    const lastLocation = locationNames.pop();
    return `${locationNames.join(', ')} and ${lastLocation}`;
  }
}

/**
 * Formats activities for display
 * @param {array} activities - Array of activity objects
 * @returns {string} - Formatted activities string
 */
function formatActivities(activities) {
  if (!activities || activities.length === 0) return 'various activities';
  
  if (activities.length === 1) {
    return activities[0].name;
  } else {
    const activityNames = activities.map(act => act.name);
    const lastActivity = activityNames.pop();
    return `${activityNames.join(', ')} and ${lastActivity}`;
  }
}

/**
 * Formats dates for display
 * @param {array} dates - Array of date objects
 * @returns {string} - Formatted dates string
 */
function formatDates(dates) {
  if (!dates || dates.length === 0) return 'flexible dates';
  
  if (dates[0].type === 'season') {
    return dates[0].value;
  } else if (dates[0].type === 'month') {
    return dates[0].value;
  } else {
    return 'your selected dates';
  }
}

/**
 * Updates sentiment score based on user message
 * @param {string} message - User's message
 */
function updateSentiment(message) {
  const lowerMessage = message.toLowerCase();
  
  // Simple sentiment analysis
  const positiveWords = ['great', 'good', 'excellent', 'amazing', 'love', 'perfect', 'wonderful', 'awesome', 'thanks', 'thank you', 'helpful', 'nice', 'yes', 'yeah'];
  const negativeWords = ['bad', 'terrible', 'awful', 'horrible', 'hate', 'dislike', 'poor', 'disappoint', 'not good', 'no', 'nope'];
  
  let sentimentChange = 0;
  
  positiveWords.forEach(word => {
    if (lowerMessage.includes(word)) sentimentChange += 1;
  });
  
  negativeWords.forEach(word => {
    if (lowerMessage.includes(word)) sentimentChange -= 1;
  });
  
  // Update sentiment score (clamped between -10 and 10)
  chatContext.sentimentScore = Math.max(-10, Math.min(10, chatContext.sentimentScore + sentimentChange));
  console.log('Updated sentiment score:', chatContext.sentimentScore);
}

/**
 * Finds and shows recommended destinations based on user preferences
 */
function showRecommendedDestinations() {
  if (allDestinations.length === 0) {
    addBotMessage("I'm having trouble accessing our destination database right now. Please try again later.");
    return;
  }
  
  // Filter destinations based on user preferences using advanced matching
  let recommendations = findMatchingDestinations();
  
  // If no recommendations found, relax constraints
  if (recommendations.length === 0) {
    broadenSearchCriteria();
    recommendations = findMatchingDestinations();
    
    // If still no recommendations, just take some popular options
    if (recommendations.length === 0) {
      recommendations = allDestinations
        .sort((a, b) => b.popularityScore - a.popularityScore)
        .slice(0, 3);
    }
  }
  
  // Limit to top 3-5 recommendations
  recommendations = recommendations.slice(0, 5);
  
  // Store recommendations in context
  chatContext.recommendations = recommendations;
  
  // Display recommendations
  let message = "<strong>Based on your preferences, here are my top recommendations:</strong><br><br>";
  
  recommendations.forEach((dest, index) => {
    message += `<strong>${index + 1}. ${dest.name}</strong> - $${dest.price}<br>`;
    message += `${dest.description.substring(0, 120)}...<br><br>`;
  });
  
  message += "Which destination would you like to learn more about? (Type the number or name)";
  addBotMessage(message);
  
  // Add suggestion chips for each destination
  const suggestions = recommendations.map((dest, i) => `${i+1}. ${dest.name.split(',')[0]}`);
  updateSuggestions(suggestions);
}

/**
 * Finds destinations that match the user's preferences
 * @returns {array} - Array of matching destinations
 */
function findMatchingDestinations() {
  return allDestinations.filter(dest => {
    let score = 0;
    const prefs = chatContext.preferences;
    
    // Budget filter - most important
    if (prefs.budget) {
      if (dest.price > prefs.budget.max) {
        return false;
      }
      // Prefer destinations close to max budget (assumption: more expensive = better)
      score += (dest.price / prefs.budget.max) * 10;
    }
    
    // Location filter
    if (prefs.location && prefs.location !== 'anywhere') {
      const nameMatch = dest.name.toLowerCase().includes(prefs.location.toLowerCase());
      const descMatch = dest.description.toLowerCase().includes(prefs.location.toLowerCase());
      
      if (!nameMatch && !descMatch) {
        // Check for region match as fallback
        if (prefs.region && dest.region === prefs.region) {
          score += 5;
        } else {
          score -= 10; // Location mismatch penalty
        }
      } else {
        score += 15; // Location match bonus
      }
    }
    
    // Season suitability
    if (prefs.season && dest.climate) {
      const seasonClimateMatch = isSeasonSuitableForClimate(prefs.season, dest.climate);
      if (seasonClimateMatch) {
        score += 8;
      }
    }
    
    // Activity match
    if (prefs.activities && prefs.activities.length > 0) {
      let activityMatchCount = 0;
      
      prefs.activities.forEach(activity => {
        // Direct description match
        if (dest.description.toLowerCase().includes(activity.name.toLowerCase())) {
          activityMatchCount++;
        }
        // Category match
        else if (dest.activityCategories && dest.activityCategories.includes(activity.category)) {
          activityMatchCount += 0.5;
        }
      });
      
      const activityMatchScore = (activityMatchCount / prefs.activities.length) * 10;
      score += activityMatchScore;
    }
    
    // Duration suitability (smaller destinations better for short trips)
    if (prefs.duration) {
      if (prefs.duration <= 3 && dest.description.length < 300) {
        score += 5; // Small destinations good for weekends
      } else if (prefs.duration >= 7 && dest.description.length > 400) {
        score += 5; // Larger destinations good for longer trips
      }
    }
    
    // Add popularity score
    score += dest.popularityScore || 0;
    
    // Store match score on destination
    dest.matchScore = score;
    
    // Include if score is positive
    return score > 0;
  })
  .sort((a, b) => b.matchScore - a.matchScore);
}

/**
 * Determines if a season is suitable for a climate
 * @param {string} season - Season name
 * @param {string} climate - Climate name
 * @returns {boolean} - Whether the season is suitable
 */
function isSeasonSuitableForClimate(season, climate) {
  const bestMatches = {
    'tropical': ['winter', 'spring', 'fall', 'autumn'], // Avoid summer (too hot/humid)
    'mediterranean': ['spring', 'fall', 'autumn'], // Best shoulder seasons
    'desert': ['winter', 'fall', 'autumn'], // Avoid summer (too hot)
    'alpine': ['summer', 'winter'], // Good for winter sports or summer hiking
    'northern': ['summer'] // Best in summer
  };
  
  return bestMatches[climate] && bestMatches[climate].includes(season);
}

/**
 * Broadens search criteria when no results are found
 */
function broadenSearchCriteria() {
  const prefs = chatContext.preferences;
  
  // Increase budget by 50%
  if (prefs.budget) {
    prefs.budget.max = prefs.budget.max * 1.5;
  }
  
  // Broaden location to region level
  if (prefs.location && prefs.location !== 'anywhere' && prefs.region) {
    prefs.location = prefs.region;
  } else {
    prefs.location = 'anywhere';
  }
  
  console.log('Broadened search criteria:', prefs);
}

/**
 * Shows detailed information about a destination
 * @param {object} destination - Destination object
 */
function showDestinationDetails(destination) {
  if (!destination) return;
  
  let message = `<strong>${destination.name}</strong><br><br>`;
  message += `<strong>Price:</strong> $${destination.price} per person<br><br>`;
  message += `${destination.description}<br><br>`;
  
  // Add information about best time to visit
  if (destination.climate) {
    message += `<strong>Best time to visit:</strong> ${getBestTimeToVisit(destination.climate)}<br><br>`;
  }
  
  // Add activity highlights
  if (destination.activityCategories && destination.activityCategories.length > 0) {
    message += `<strong>Highlights:</strong> ${destination.activityCategories.join(', ')}<br><br>`;
  }
  
  message += `Would you like to book this destination?`;
  
  addBotMessage(message);
  updateSuggestions(['Book this trip', 'Tell me more about activities', 'Show other options']);
}

/**
 * Shows detailed activity information for a destination
 * @param {object} destination - Destination object
 */
function showDestinationActivities(destination) {
  if (!destination) return;
  
  let activities = "Here are some popular activities and experiences in " + destination.name + ":<br><br>";
  
  // Generate activities based on destination info and categories
  if (destination.activityCategories) {
    destination.activityCategories.forEach(category => {
      switch(category) {
        case 'beaches':
          activities += "🏖️ <strong>Beach Activities:</strong> Enjoy pristine beaches, swimming in crystal-clear waters, sunbathing, and beach sports.<br><br>";
          break;
        case 'nature':
          activities += "🌳 <strong>Nature Experiences:</strong> Explore stunning natural landscapes, hiking trails, and scenic viewpoints.<br><br>";
          break;
        case 'culture':
          activities += "🏛️ <strong>Cultural Attractions:</strong> Visit museums, historical sites, architectural wonders, and immerse yourself in local traditions.<br><br>";
          break;
        case 'food':
          activities += "🍽️ <strong>Culinary Experiences:</strong> Sample local cuisine, visit markets, enjoy street food, or dine at authentic restaurants.<br><br>";
          break;
        case 'adventure':
          activities += "🧗 <strong>Adventure Activities:</strong> Try exciting outdoor activities like hiking, climbing, water sports, or adventure tours.<br><br>";
          break;
        case 'relaxation':
          activities += "💆 <strong>Relaxation:</strong> Unwind at spas, wellness centers, or peaceful retreats away from the hustle and bustle.<br><br>";
          break;
        case 'nightlife':
          activities += "🌃 <strong>Nightlife:</strong> Experience vibrant bars, clubs, and entertainment venues after dark.<br><br>";
          break;
        case 'shopping':
          activities += "🛍️ <strong>Shopping:</strong> Explore local markets, boutiques, and shopping districts for souvenirs and local crafts.<br><br>";
          break;
      }
    });
  }
  
  // Add recommendation based on user preferences
  if (chatContext.preferences.activities.length > 0) {
    activities += "<strong>Recommended for you:</strong> Based on your interests, you might particularly enjoy ";
    
    const userActivities = chatContext.preferences.activities.map(a => a.name);
    activities += userActivities.join(', ') + ".<br><br>";
  }
  
  activities += "Would you like to proceed with booking this destination?";
  
  addBotMessage(activities);
  updateSuggestions(['Book this trip', 'Weather information', 'Show other options']);
}

/**
 * Shows weather information for a destination
 * @param {object} destination - Destination object
 */
function showDestinationWeather(destination) {
  if (!destination) return;
  
  let weather = `<strong>Climate and Weather in ${destination.name}</strong><br><br>`;
  
  // Generate weather info based on climate zone
  if (destination.climate) {
    switch(destination.climate) {
      case 'tropical':
        weather += "🌡️ <strong>Climate:</strong> Tropical<br>";
        weather += "The region enjoys warm temperatures year-round with highs between 75-90°F (24-32°C).<br><br>";
        weather += "🌧️ <strong>Wet/Dry Seasons:</strong><br>";
        weather += "• Dry season (December-April): Lower humidity and less rainfall<br>";
        weather += "• Wet season (May-November): Higher humidity with afternoon showers<br><br>";
        break;
      case 'mediterranean':
        weather += "🌡️ <strong>Climate:</strong> Mediterranean<br>";
        weather += "Characterized by hot, dry summers and mild, wet winters.<br><br>";
        weather += "🌞 <strong>Seasonal Variations:</strong><br>";
        weather += "• Summer (June-August): Hot and dry with temperatures 75-90°F (24-32°C)<br>";
        weather += "• Spring/Fall (April-May/Sept-Oct): Mild temperatures 65-75°F (18-24°C)<br>";
        weather += "• Winter (November-March): Mild with some rainfall, 50-65°F (10-18°C)<br><br>";
        break;
      case 'desert':
        weather += "🌡️ <strong>Climate:</strong> Desert<br>";
        weather += "Arid with extreme temperature variations between day and night.<br><br>";
        weather += "🌞 <strong>Seasonal Variations:</strong><br>";
        weather += "• Summer (May-September): Very hot with temperatures 90-110°F (32-43°C)<br>";
        weather += "• Winter (November-March): Mild days 65-75°F (18-24°C) but cold nights<br><br>";
        break;
      case 'alpine':
        weather += "🌡️ <strong>Climate:</strong> Alpine<br>";
        weather += "Mountain climate with significant variations based on elevation.<br><br>";
        weather += "❄️ <strong>Seasonal Variations:</strong><br>";
        weather += "• Summer (June-August): Mild with temperatures 60-75°F (15-24°C)<br>";
        weather += "• Winter (December-March): Cold with snow, temperatures 20-40°F (-6-4°C)<br><br>";
        break;
      case 'northern':
        weather += "🌡️ <strong>Climate:</strong> Northern<br>";
        weather += "Distinct seasons with cold winters and mild summers.<br><br>";
        weather += "🌞 <strong>Seasonal Variations:</strong><br>";
        weather += "• Summer (June-August): Mild with long daylight hours, 60-75°F (15-24°C)<br>";
        weather += "• Winter (November-March): Cold with snow and limited daylight, 10-40°F (-12-4°C)<br><br>";
        break;
      default:
        weather += "This destination experiences varying weather patterns throughout the year.<br><br>";
    }
  }
  
  // Add recommendation based on user's selected season
  if (chatContext.preferences.season) {
    weather += `<strong>Your Travel Period (${chatContext.preferences.season}):</strong><br>`;
    const suitability = isSeasonSuitableForClimate(chatContext.preferences.season, destination.climate);
    
    if (suitability) {
      weather += `${chatContext.preferences.season.charAt(0).toUpperCase() + chatContext.preferences.season.slice(1)} is an excellent time to visit ${destination.name}. You can expect favorable weather conditions for most activities.<br><br>`;
    } else {
      weather += `While ${chatContext.preferences.season} is not typically considered the ideal time to visit due to weather conditions, the destination still offers many attractions. Consider packing appropriate clothing for the conditions.<br><br>`;
    }
  }
  
  weather += "Would you like to proceed with booking this destination?";
  
  addBotMessage(weather);
  updateSuggestions(['Book this trip', 'Activity information', 'Cost details']);
}

/**
 * Shows cost breakdown for a destination
 * @param {object} destination - Destination object
 */
function showDestinationCosts(destination) {
  if (!destination) return;
  
  const numTravelers = chatContext.preferences.travelers || 1;
  const duration = chatContext.preferences.duration || 7;
  
  // Calculate estimated costs
  const basePrice = destination.price;
  const accommodationCost = Math.round(basePrice * 0.5) * duration / 7; // Per person
  const flightCost = Math.round(basePrice * 0.3); // Per person
  const foodCost = Math.round(basePrice * 0.15) * duration / 7; // Per person
  const activitiesCost = Math.round(basePrice * 0.2) * duration / 7; // Per person
  const totalPerPerson = Math.round(basePrice + accommodationCost + flightCost + foodCost + activitiesCost);
  const totalForGroup = totalPerPerson * numTravelers;
  
  let costs = `<strong>Estimated Costs for ${destination.name}</strong><br><br>`;
  costs += `These estimates are for ${numTravelers} ${numTravelers === 1 ? 'person' : 'people'} for a ${duration}-day trip:<br><br>`;
  
  costs += "🏨 <strong>Accommodation:</strong> $" + Math.round(accommodationCost) + " per person<br>";
  costs += "✈️ <strong>Flights:</strong> $" + Math.round(flightCost) + " per person<br>";
  costs += "🍽️ <strong>Food & Drinks:</strong> $" + Math.round(foodCost) + " per person<br>";
  costs += "🎟️ <strong>Activities & Excursions:</strong> $" + Math.round(activitiesCost) + " per person<br>";
  costs += "💰 <strong>Total per person:</strong> $" + totalPerPerson + "<br>";
  costs += `💼 <strong>Total for ${numTravelers} ${numTravelers === 1 ? 'person' : 'people'}:</strong> $${totalForGroup}<br><br>`;
  
  costs += "These are estimates and actual costs may vary based on your specific choices, season of travel, and current rates.<br><br>";
  costs += "Would you like to proceed with booking this destination?";
  
  addBotMessage(costs);
  updateSuggestions(['Book this trip', 'Weather information', 'Activity information']);
}

/**
 * Gets best time to visit based on climate
 * @param {string} climate - Climate zone
 * @returns {string} - Best time to visit
 */
function getBestTimeToVisit(climate) {
  switch (climate) {
    case 'tropical':
      return "December to April (dry season)";
    case 'mediterranean':
      return "April to June and September to October";
    case 'desert':
      return "October to April";
    case 'alpine':
      return "December to March for winter sports, June to September for hiking";
    case 'northern':
      return "May to September";
    default:
      return "Varies throughout the year";
  }
}

/**
 * Extracts destination name from user message
 * @param {string} message - User's message
 * @returns {string} - Extracted destination name
 */
function extractDestinationName(message) {
  const lowerMessage = message.toLowerCase();
  
  for (const dest of allDestinations) {
    const destName = dest.name.toLowerCase();
    // Extract the city name (before comma)
    const cityName = destName.split(',')[0].trim();
    
    if (lowerMessage.includes(destName) || lowerMessage.includes(cityName)) {
      return dest.name;
    }
  }
  
  return null;
}

/**
 * Finds a destination by name
 * @param {string} name - Destination name to find
 * @returns {object} - Found destination or null
 */
function findDestinationByName(name) {
  if (!name) return null;
  
  // First try exact match
  const exactMatch = allDestinations.find(dest => 
    dest.name.toLowerCase() === name.toLowerCase()
  );
  
  if (exactMatch) return exactMatch;
  
  // Then try partial match
  const partialMatch = allDestinations.find(dest => 
    dest.name.toLowerCase().includes(name.toLowerCase())
  );
  
  return partialMatch || null;
}

/**
 * Initiates the booking process for the current destination
 */
function initiateBookingProcess() {
  const destination = chatContext.currentDestination;
  if (!destination) return;
  
  const numTravelers = chatContext.preferences.travelers || 1;
  const duration = chatContext.preferences.duration || 7;
  
  addBotMessage(`Great! I'll help you book your trip to ${destination.name} for ${numTravelers} ${numTravelers === 1 ? 'person' : 'people'} for ${duration} days. Redirecting you to complete your booking...`);
  
  // Delay before redirect
  setTimeout(() => {
    window.location.href = `book.html?destination=${encodeURIComponent(destination.name)}&travelers=${numTravelers}&duration=${duration}`;
  }, 2000);
}

/**
 * Redirects to login page with return destination
 */
function redirectToLogin() {
  const destination = chatContext.currentDestination;
  if (!destination) return;
  
  addBotMessage("To complete your booking, you'll need to log in. I'll redirect you to the login page, and then you can continue with your booking.");
  
  // Delay before redirect
  setTimeout(() => {
    window.location.href = `login.html?redirect=book&destination=${encodeURIComponent(destination.name)}`;
  }, 2000);
}

/**
 * Resets the conversation context
 */
function resetContext() {
  chatContext = {
    currentState: CHAT_STATES.GREETING,
    conversationHistory: chatContext.conversationHistory,
    userProfile: chatContext.userProfile,
    sentimentScore: 0,
    preferences: {
      budget: null,
      location: null,
      region: null,
      continent: null,
      travelers: null,
      season: null,
      duration: null,
      activities: [],
      climate: null,
      mustHaves: [],
      dealBreakers: []
    },
    recommendations: [],
    currentDestination: null,
    fallbackAttempts: 0
  };
  
  console.log('Context reset.');
}

/**
 * Shows popular destinations
 */
function showPopularDestinations() {
  // Sort destinations by popularity score
  const popularDests = [...allDestinations]
    .sort((a, b) => (b.popularityScore || 0) - (a.popularityScore || 0))
    .slice(0, 5);
  
  let message = "<strong>Top Popular Destinations for 2025:</strong><br><br>";
  
  popularDests.forEach((dest, index) => {
    message += `<strong>${index + 1}. ${dest.name}</strong> - $${dest.price}<br>`;
    message += `${dest.description.substring(0, 100)}...<br><br>`;
  });
  
  message += "Would you like more information about any of these destinations? (Type the number or name)";
  
  addBotMessage(message);
  chatContext.recommendations = popularDests;
  chatContext.currentState = CHAT_STATES.SHOW_RESULTS;
  
  // Add suggestion chips for each destination
  const suggestions = popularDests.map((dest, i) => `${i+1}. ${dest.name.split(',')[0]}`);
  updateSuggestions(suggestions);
}

/**
 * Shows travel tips
 */
function showTravelTips() {
  const tips = `<strong>Essential Travel Tips:</strong><br><br>
  
  ✅ <strong>Book in advance</strong> for better rates, especially during peak seasons<br><br>
  
  🧳 <strong>Pack smart</strong> - research weather at your destination and pack versatile clothing<br><br>
  
  💳 <strong>Notify your bank</strong> about your travel plans to avoid card freezes<br><br>
  
  📱 <strong>Download offline maps</strong> and translation apps before departure<br><br>
  
  💊 <strong>Carry basic medications</strong> and a small first-aid kit<br><br>
  
  📝 <strong>Make copies of important documents</strong> like passports and store digitally<br><br>
  
  🔒 <strong>Use hotel safes</strong> for valuables and important documents<br><br>
  
  Would you like me to help you find a specific destination based on your preferences?`;
  
  addBotMessage(tips);
  updateSuggestions(['Find a destination', 'More travel advice', 'Popular destinations']);
}

/**
 * Shows best time to travel information
 */
function showBestTimeToTravel() {
  const info = `<strong>Best Times to Travel by Region:</strong><br><br>
  
  🌍 <strong>Europe:</strong><br>
  • Best: April-June, September-October (pleasant weather, fewer crowds)<br>
  • Avoid: July-August (peak season, crowded, expensive)<br><br>
  
  🌏 <strong>Asia:</strong><br>
  • Southeast Asia: November-February (dry season)<br>
  • Japan & Korea: March-May (cherry blossoms) or October-November (fall colors)<br>
  • India: October-March (cooler, drier weather)<br><br>
  
  🌎 <strong>North America:</strong><br>
  • USA/Canada: May-June, September-October (mild weather, lower crowds)<br>
  • Caribbean: December-April (dry season, but higher prices)<br><br>
  
  🌍 <strong>Africa:</strong><br>
  • Safari: June-October (dry season, better wildlife viewing)<br>
  • Morocco: March-May, September-November (milder temperatures)<br><br>
  
  🌏 <strong>Oceania:</strong><br>
  • Australia: September-November, March-May (spring and autumn)<br>
  • New Zealand: December-February (summer) or June-August (winter for skiing)<br><br>
  
  Would you like me to help you plan a trip for a specific season?`;
  
  addBotMessage(info);
  updateSuggestions(['Plan a summer trip', 'Plan a winter trip', 'Plan a trip to Europe', 'Plan a trip to Asia']);
}

/**
 * Shows information about Eazy Travel
 */
function showAboutEazyTravel() {
  const about = `<strong>About Eazy Travel</strong><br><br>
  
  🌐 <strong>Who We Are:</strong><br>
  Eazy Travel is a full-service travel platform dedicated to helping travelers discover and book their perfect vacation experience. Founded in 2023, we've quickly grown to become a trusted name in personalized travel planning.<br><br>
  
  🛠️ <strong>Our Services:</strong><br>
  • Personalized destination recommendations<br>
  • Complete vacation packages<br>
  • Customized itinerary planning<br>
  • 24/7 travel support<br>
  • Best price guarantees<br><br>
  
  🤝 <strong>Our Promise:</strong><br>
  We're committed to making travel planning truly "eazy" by combining cutting-edge technology with personalized service. Our AI assistant and expert team work together to ensure every trip meets your unique preferences and expectations.<br><br>
  
  Would you like to explore destinations or learn about our current deals?`;
  
  addBotMessage(about);
  updateSuggestions(['Explore destinations', 'Current deals', 'Start planning my trip']);
}

/**
 * Generates a custom response for miscellaneous queries
 * @param {string} message - User's message
 * @returns {string} - Generated response
 */
function generateCustomResponse(message) {
  const lowerMessage = message.toLowerCase();
  
  // Check for common travel questions
  if (lowerMessage.includes('visa') || lowerMessage.includes('passport')) {
    return "Visa and passport requirements vary by destination and your citizenship. I recommend checking the official embassy website of your destination country or consulting with a travel agent for the most up-to-date requirements.";
  }
  
  if (lowerMessage.includes('insurance') || lowerMessage.includes('travel insurance')) {
    return "Travel insurance is highly recommended for all trips. Look for policies that cover medical emergencies, trip cancellation, lost luggage, and any specific activities you plan to participate in. The cost typically ranges from 4-10% of your total trip price.";
  }
  
  if (lowerMessage.includes('covid') || lowerMessage.includes('pandemic') || lowerMessage.includes('vaccination')) {
    return "Travel requirements related to health situations change frequently. I recommend checking the CDC, WHO, or your destination's official tourism website for the most current information before booking and again before traveling.";
  }
  
  if (lowerMessage.includes('cheapest') || lowerMessage.includes('affordable') || lowerMessage.includes('budget')) {
    return "For budget-friendly travel, consider destinations like Southeast Asia (Thailand, Vietnam), parts of Eastern Europe (Hungary, Poland), and Latin America (Mexico, Colombia). Traveling during shoulder seasons (just before or after peak season) can also save you significant money while still offering good weather.";
  }
  
  if (lowerMessage.includes('safe') || lowerMessage.includes('safety')) {
    return "Safety varies by destination and can change over time. Generally, countries like Iceland, New Zealand, Japan, and Switzerland consistently rank among the safest for travelers. Always research current conditions before booking and take standard precautions like securing valuables and staying aware of your surroundings.";
  }
  
  // Generic response for other queries
  return "That's a great question about travel! While I don't have all the specific details, I'd be happy to help you find destinations that match your preferences and create a personalized travel plan.";
}

// Add CSS for the chatbot to the page
function addChatbotStyles() {
  const style = document.createElement('style');
  style.textContent = `
    .suggestion-chips {
      display: flex;
      flex-wrap: wrap;
      gap: 0.5rem;
      margin: 1rem 0;
    }
    
    .suggestion-chip {
      background-color: #f0f7ff;
      border: 1px solid #c0d8ff;
      border-radius: 18px;
      padding: 0.5rem 1rem;
      font-size: 0.9rem;
      cursor: pointer;
      transition: background-color 0.2s;
    }
    
    .suggestion-chip:hover {
      background-color: #e0f0ff;
    }
    
    .message a {
      color: #007bff;
      text-decoration: none;
    }
    
    .message a:hover {
      text-decoration: underline;
    }
    
    @keyframes typing {
      0% { transform: translateY(0); }
      50% { transform: translateY(-5px); }
      100% { transform: translateY(0); }
    }
  `;
  document.head.appendChild(style);
}

// Call this on load
document.addEventListener('DOMContentLoaded', addChatbotStyles);