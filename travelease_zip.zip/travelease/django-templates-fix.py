#!/usr/bin/env python
"""
Script to fix Django templates for TravelEase.
This uses your existing folder structure without major reorganization.
"""

import os
import shutil

def fix_templates():
    """Fix Django templates to properly reference static files"""
    # Base directories
    base_dir = os.path.dirname(os.path.abspath(__file__))
    templates_dir = os.path.join(base_dir, 'templates')
    
    # Create templates directory if it doesn't exist
    if not os.path.exists(templates_dir):
        os.makedirs(templates_dir)
        print(f"Created directory: {templates_dir}")
    
    # Create base.html template
    with open(os.path.join(templates_dir, 'base.html'), 'w') as f:
        f.write('''{% load static %}
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Eazy Travel</title>
  <link rel="stylesheet" href="{% static 'css/style.css' %}">
  <link rel="stylesheet" href="{% static 'css/chatbot-styles.css' %}">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
  <!-- Navigation Bar -->
  <nav class="navbar">
    <div class="nav-container">
      <a href="{% url 'index' %}" class="logo">Eazy Travel</a>
      <ul class="nav-links">
        <li><a href="{% url 'index' %}">Home</a></li>
        <li><a href="{% url 'places_page' %}">Destinations</a></li>
        <li><a href="{% url 'map_page' %}">Map</a></li>
        <li><a href="{% url 'book_page' %}">Book</a></li>
        <li><a href="{% url 'itineraries_page' %}">My Trips</a></li>
        <li><a href="{% url 'login_page' %}">Login</a></li>
      </ul>
    </div>
  </nav>

  <!-- Page Content -->
  <main>
    {% block content %}
    <!-- Replace this with specific page content -->
    {% endblock %}
  </main>

  <!-- Footer -->
  <footer class="footer">
    <p>&copy; 2025 Eazy Travel. All rights reserved.</p>
  </footer>
  
  {% block extra_scripts %}{% endblock %}
</body>
</html>''')
    print("Created base.html template")
    
    # HTML files to process
    html_files = {
        'index.html': '''{% extends 'base.html' %}
{% load static %}

{% block content %}
  <!-- Header -->
  <header class="hero back">
    <div class="container text-center">
      <h1>Discover Amazing Places</h1>
      <p>Explore the world's most beautiful destinations, create personalized itineraries, and share your experiences with fellow travelers.</p>
      <div class="buttons">
        <a href="{% url 'places_page' %}" class="btn btn-primary">
          <i class="fas fa-search"></i> Explore Places
        </a>
        <a href="{% url 'map_page' %}" class="btn btn-outline">
          <i class="fas fa-map-marked-alt"></i> Open Map
        </a>
      </div>
    </div>
  </header>

  <!-- Chat Assistant -->
  <section class="chat-container">
    <div class="chat-header">
      <img src="https://source.unsplash.com/40x40/?robot" alt="AI Assistant">
      <h3>Travel Assistant</h3>
    </div>
    <div class="chat-box" id="chatBox">
      <!-- Messages will appear here dynamically -->
    </div>
    <div class="typing-indicator" id="typingIndicator">
      <span></span>
      <span></span>
      <span></span>
    </div>
    <!-- The suggestion chips container will be created by the JS -->
    <div class="user-input">
      <input type="text" id="userInput" placeholder="Ask about travel destinations...">
      <button id="sendButton">Send</button>
    </div>
  </section>

  <!-- Featured Places -->
  <section class="featured">
    <div class="section-header">
      <h2>Featured Places</h2>
      <a href="{% url 'places_page' %}" class="btn-link">View All</a>
    </div>
    <div class="destination-grid" id="destinationGrid"></div>
  </section>
{% endblock %}

{% block extra_scripts %}
  <!-- Load our chatbot script first -->
  <script src="{% static 'js/advanced-travel-chatbot.js' %}"></script>
  
  <!-- Load main.js for other functionality -->
  <script src="{% static 'js/main.js' %}"></script>
{% endblock %}''',
        
        'login.html': '''{% extends 'base.html' %}
{% load static %}

{% block content %}
  <main class="featured" style="max-width: 400px;">
    <h2>Login to Your Account</h2>
    <form>
      <label for="name">username</label>
      <input type="name" id="login-username" name="name" required>

      <label for="password">Password</label>
      <input type="password" id="login-password" name="password" required>

      <div style="display: flex; align-items: center; margin: 0.5rem 0;">
        <input type="checkbox" id="remember" name="remember" style="margin-right: 0.5rem;">
        <label for="remember">Remember me</label>
      </div>

      <button id="loginBtn" type="submit" class="btn btn-primary" style="width: 100%;">Login</button>

      <p style="margin-top: 1rem; font-size: 0.9rem;">
        <a href="#">Forgot your password?</a><br>
        Don't have an account? <a href="{% url 'signup_page' %}">Sign up here</a>
      </p>
    </form>
  </main>
{% endblock %}

{% block extra_scripts %}
  <script src="{% static 'js/login.js' %}"></script>
{% endblock %}'''
    }
    
    # Process each HTML file
    for filename, content in html_files.items():
        with open(os.path.join(templates_dir, filename), 'w') as f:
            f.write(content)
        print(f"Created template: {filename}")
    
    # Update Django settings
    settings_path = os.path.join(base_dir, 'travelease', 'settings.py')
    if os.path.exists(settings_path):
        with open(settings_path, 'r') as f:
            settings_content = f.read()
        
        # Update settings
        new_settings = '''
# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATICFILES_DIRS = [
    os.path.join(BASE_DIR, 'public'),
]
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

# Template settings
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]
'''
        # Replace the existing template section in settings.py
        if 'TEMPLATES = [' in settings_content:
            start_index = settings_content.find('TEMPLATES = [')
            end_index = settings_content.find(']', start_index)
            end_index = settings_content.find(']', end_index + 1) + 1
            
            settings_content = settings_content[:start_index] + new_settings + settings_content[end_index:]
            
            with open(settings_path, 'w') as f:
                f.write(settings_content)
            print("Updated settings.py with new template and static file configurations")
    
    # Create a simple script to update view_pages.py
    with open(os.path.join(base_dir, 'update_views.py'), 'w') as f:
        f.write('''"""
Script to update views_pages.py to use templates directory.
"""

import os

# Path to view_pages.py
view_pages_path = os.path.join('api', 'view_pages.py')

# New content for view_pages.py
new_content = """\"\"\"
Views for serving HTML pages for the TravelEase frontend.
\"\"\"

from django.shortcuts import render

def index(request):
    \"\"\"Render the index.html page\"\"\"
    return render(request, 'index.html')

def login_page(request):
    \"\"\"Render the login.html page\"\"\"
    return render(request, 'login.html')

def signup_page(request):
    \"\"\"Render the signup.html page\"\"\"
    return render(request, 'signup.html')

def profile_page(request):
    \"\"\"Render the profile.html page\"\"\"
    return render(request, 'profile.html')

def map_page(request):
    \"\"\"Render the map.html page\"\"\"
    return render(request, 'map.html')

def places_page(request):
    \"\"\"Render the places.html page\"\"\"
    return render(request, 'places.html')

def place_detail_page(request):
    \"\"\"Render the place_detail.html page\"\"\"
    return render(request, 'place_detail.html')

def book_page(request):
    \"\"\"Render the book.html page\"\"\"
    return render(request, 'book.html')

def booking_success_page(request):
    \"\"\"Render the booking_success.html page\"\"\"
    return render(request, 'booking_success.html')

def itineraries_page(request):
    \"\"\"Render the itineraries.html page\"\"\"
    return render(request, 'itineraries.html')
"""

# Update the file
with open(view_pages_path, 'w') as f:
    f.write(new_content)

print("Updated view_pages.py to use templates directory")
''')
    print("Created update_views.py script to fix view_pages.py file")
    
    print("\nTemplate fixes complete!")
    print("\nTo finish the setup, run these commands:")
    print("1. python update_views.py")
    print("2. python manage.py collectstatic")
    print("3. python run.py\n")

if __name__ == "__main__":
    fix_templates()