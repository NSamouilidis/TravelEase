#!/usr/bin/env python
"""
Script to fix frontend file paths if needed.
This script makes sure the frontend files are in the correct location
and have the correct references to CSS and JS files.
"""

import os
import shutil
import glob

def ensure_directory(directory):
    """Make sure directory exists"""
    if not os.path.exists(directory):
        os.makedirs(directory)
        print(f"Created directory: {directory}")

def fix_frontend_paths():
    """Fix frontend file paths"""
    # Base directories
    base_dir = os.path.dirname(os.path.abspath(__file__))
    public_dir = os.path.join(base_dir, 'public')
    
    # Make sure public directory exists
    ensure_directory(public_dir)
    ensure_directory(os.path.join(public_dir, 'css'))
    ensure_directory(os.path.join(public_dir, 'js'))
    
    # Check for HTML files in the root
    html_files = glob.glob(os.path.join(base_dir, '*.html'))
    for html_file in html_files:
        file_name = os.path.basename(html_file)
        dest_path = os.path.join(public_dir, file_name)
        
        if not os.path.exists(dest_path):
            shutil.copy(html_file, dest_path)
            print(f"Copied HTML file to public: {file_name}")
    
    # Check for CSS files
    css_files = glob.glob(os.path.join(base_dir, '*.css'))
    css_files += glob.glob(os.path.join(base_dir, 'css', '*.css'))
    
    for css_file in css_files:
        file_name = os.path.basename(css_file)
        dest_path = os.path.join(public_dir, 'css', file_name)
        
        if not os.path.exists(dest_path):
            shutil.copy(css_file, dest_path)
            print(f"Copied CSS file to public/css: {file_name}")
    
    # Check for JS files
    js_files = glob.glob(os.path.join(base_dir, '*.js'))
    js_files += glob.glob(os.path.join(base_dir, 'js', '*.js'))
    
    for js_file in js_files:
        file_name = os.path.basename(js_file)
        # Skip Django and Node.js files
        if file_name in ['manage.py', 'setup_db.py', 'run.py', 'fix_frontend_paths.py']:
            continue
            
        dest_path = os.path.join(public_dir, 'js', file_name)
        
        if not os.path.exists(dest_path):
            shutil.copy(js_file, dest_path)
            print(f"Copied JS file to public/js: {file_name}")
    
    print("\nFrontend paths fixed. If you still have issues, make sure to:")
    print("1. Check all HTML files are in the 'public' directory")
    print("2. Check all CSS files are in the 'public/css' directory")
    print("3. Check all JS files are in the 'public/js' directory")
    print("4. Run 'python manage.py collectstatic' to collect static files")

if __name__ == "__main__":
    fix_frontend_paths()