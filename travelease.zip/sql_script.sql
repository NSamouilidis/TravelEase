-- Complete MySQL Script for TravelEase Database Setup

-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS travelease CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Use the travelease database
USE travelease;

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create destinations table
CREATE TABLE IF NOT EXISTS destinations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    image_url VARCHAR(500) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    description TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create bookings table
CREATE TABLE IF NOT EXISTS bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    destination VARCHAR(255) NOT NULL,
    transport VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    num_people INT NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Create indexes for better performance
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_destinations_name ON destinations(name);
CREATE INDEX idx_bookings_user_id ON bookings(user_id);
CREATE INDEX idx_bookings_destination ON bookings(destination);

-- Insert sample destinations data
INSERT INTO destinations (name, image_url, price, description) VALUES
('Paris, France', 'https://source.unsplash.com/800x600/?paris', 1200.00, 'Explore the romantic streets of Paris, visit the iconic Eiffel Tower, Louvre Museum, and enjoy exquisite French cuisine. Paris offers a perfect blend of history, art, and culinary experiences, making it one of the most visited cities in the world.'),

('Bali, Indonesia', 'https://source.unsplash.com/800x600/?bali', 850.00, 'Experience the tropical paradise of Bali with its stunning beaches, lush rice terraces, and spiritual temples. Perfect for relaxation, adventure, and cultural immersion. Enjoy affordable luxury accommodations, traditional Balinese massages, and vibrant nightlife.'),

('Kyoto, Japan', 'https://source.unsplash.com/800x600/?kyoto', 1050.00, 'Discover the traditional side of Japan in Kyoto, home to thousands of classical Buddhist temples, gardens, imperial palaces, Shinto shrines, and traditional wooden houses. Experience the geisha culture in Gion district and the serene bamboo forests of Arashiyama.'),

('Rome, Italy', 'https://source.unsplash.com/800x600/?rome', 950.00, 'Step back in time in the Eternal City of Rome. Explore ancient ruins like the Colosseum and Roman Forum, toss a coin in the Trevi Fountain, and marvel at Michelangelo\'s masterpiece in the Sistine Chapel. Indulge in authentic Italian pasta, pizza, and gelato.'),

('Santorini, Greece', 'https://source.unsplash.com/800x600/?santorini', 1300.00, 'Experience the breathtaking beauty of Santorini with its white-washed buildings, blue-domed churches, and stunning sunsets over the Aegean Sea. Explore charming villages, volcanic beaches, ancient ruins, and enjoy world-class wineries and restaurants.'),

('New York City, USA', 'https://source.unsplash.com/800x600/?newyork', 1100.00, 'Discover the city that never sleeps! From iconic landmarks like Times Square and the Statue of Liberty to world-class museums, Broadway shows, diverse neighborhoods, and endless shopping and dining options, New York offers something for everyone.'),

('Bangkok, Thailand', 'https://source.unsplash.com/800x600/?bangkok', 700.00, 'Immerse yourself in the vibrant capital of Thailand. Bangkok offers a unique blend of traditional temples, bustling markets, modern shopping malls, and legendary street food. Visit the Grand Palace, float through canals on a longtail boat, and experience the famous nightlife.'),

('Cairo, Egypt', 'https://source.unsplash.com/800x600/?cairo', 750.00, 'Journey to the land of pharaohs and pyramids. Explore the ancient wonders of Egypt, including the Great Pyramids of Giza and the Sphinx. Cruise down the Nile River, visit the Egyptian Museum, and experience the bustling energy of Cairo\'s markets and streets.'),

('Sydney, Australia', 'https://source.unsplash.com/800x600/?sydney', 1250.00, 'Enjoy the stunning harbor city of Sydney with its iconic Opera House, Harbour Bridge, and beautiful beaches like Bondi and Manly. Experience a unique blend of urban excitement and natural beauty, with excellent dining, shopping, and cultural attractions.');

-- You can add more sample data as needed