"""
URL configuration for travelease project.
"""
from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from api import chatbot_api  # Import chatbot_api from the api app, not from travelease

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # Chatbot API endpoints - add these before the include()
    path('api/chatbot/recommendations', chatbot_api.get_budget_recommendations, name='get_budget_recommendations'),
    path('api/chatbot/stats', chatbot_api.get_chatbot_stats, name='get_chatbot_stats'),
    
    # Include all other API routes
    path('', include('api.urls')),
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)