/**
 * TravelEase Chatbot
 * Provides budget-based travel recommendations directly from database
 */

// Initialize chatbot when document is ready
document.addEventListener('DOMContentLoaded', () => {
    initChatbot();
});

// Chat messages
const botResponses = {
    welcome: "👋 Hi there! I'm TravelBot, your travel assistant. I can help you find destinations within your budget. What's your travel budget? (in USD)",
    budget_invalid: "Please enter a valid budget amount (a number greater than 0)",
    budget_too_low: "I couldn't find destinations at that price point. Our minimum budget is $MINPRICE. Please enter a higher amount.",
    budget_confirmed: "Great! I'll find some amazing destinations within your $BUDGET budget.",
    no_results: "I couldn't find any destinations within your budget. Try increasing your budget a bit.",
    error: "Sorry, I encountered an error while searching. Please try again later.",
    more_help: "Would you like more destination suggestions or help with something else?",
    dont_understand: "I'm not sure I understand. I can help you find destinations within your budget. Please enter your budget in USD.",
    goodbye: "Thanks for chatting! Feel free to return if you need more travel recommendations. Have a great day! 😊",
    help: "I can help you find travel destinations based on your budget. Just tell me how much you'd like to spend on your trip.",
};

// Chatbot state
let chatbotState = {
    active: false,
    waitingForBudget: false,
    currentBudget: 0,
    suggestedDestinations: [],
    stats: {
        minPrice: 500,
        maxPrice: 1500,
        avgPrice: 1000
    }
};

// Initialize the chatbot
function initChatbot() {
    // Create chatbot elements if they don't exist
    if (!document.getElementById('chatbot-container')) {
        createChatbotUI();
    }
    
    // Set up event listeners
    const chatToggle = document.getElementById('chat-toggle');
    const chatInput = document.getElementById('chat-input');
    const chatSend = document.getElementById('chat-send');
    const chatClose = document.getElementById('chat-close');
    
    // Toggle chatbot visibility
    chatToggle.addEventListener('click', () => {
        toggleChatbot();
    });
    
    // Close chatbot
    chatClose.addEventListener('click', () => {
        toggleChatbot(false);
    });
    
    // Send message on button click
    chatSend.addEventListener('click', () => {
        sendUserMessage();
    });
    
    // Send message on Enter key
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendUserMessage();
        }
    });
    
    // Load chatbot stats from the database
    loadChatbotStats();
}

// Load chatbot stats from database
async function loadChatbotStats() {
    try {
        const response = await fetch('/api/chatbot/stats');
        
        if (response.ok) {
            const stats = await response.json();
            
            // Update chatbot state with real database stats
            chatbotState.stats = {
                minPrice: Math.ceil(stats.min_price),
                maxPrice: Math.ceil(stats.max_price),
                avgPrice: Math.ceil(stats.avg_price)
            };
            
            console.log('Chatbot stats loaded:', chatbotState.stats);
        }
    } catch (error) {
        console.error('Error loading chatbot stats:', error);
    }
}

// Create chatbot UI elements
function createChatbotUI() {
    // Create chatbot toggle button
    const chatToggle = document.createElement('div');
    chatToggle.id = 'chat-toggle';
    chatToggle.innerHTML = '<i class="fas fa-comment"></i>';
    chatToggle.title = 'Chat with TravelBot';
    
    // Create chatbot container
    const chatbotContainer = document.createElement('div');
    chatbotContainer.id = 'chatbot-container';
    chatbotContainer.classList.add('chatbot-hidden');
    
    // Create chatbot header
    const chatHeader = document.createElement('div');
    chatHeader.id = 'chat-header';
    chatHeader.innerHTML = `
        <div class="chat-title">
            <i class="fas fa-robot"></i>
            <span>TravelBot</span>
        </div>
        <button id="chat-close"><i class="fas fa-times"></i></button>
    `;
    
    // Create chatbot messages area
    const chatMessages = document.createElement('div');
    chatMessages.id = 'chat-messages';
    
    // Create chatbot input area
    const chatInputArea = document.createElement('div');
    chatInputArea.id = 'chat-input-area';
    chatInputArea.innerHTML = `
        <input type="text" id="chat-input" placeholder="Type your message...">
        <button id="chat-send"><i class="fas fa-paper-plane"></i></button>
    `;
    
    // Assemble chatbot elements
    chatbotContainer.appendChild(chatHeader);
    chatbotContainer.appendChild(chatMessages);
    chatbotContainer.appendChild(chatInputArea);
    
    // Add chatbot to the page
    document.body.appendChild(chatToggle);
    document.body.appendChild(chatbotContainer);
    
    // Add chatbot styles if not already added
    if (!document.getElementById('chatbot-styles')) {
        addChatbotStyles();
    }
}

// Add chatbot CSS styles
function addChatbotStyles() {
    const styleSheet = document.createElement('style');
    styleSheet.id = 'chatbot-styles';
    styleSheet.textContent = `
        #chat-toggle {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 60px;
            height: 60px;
            background-color: var(--primary-color);
            color: white;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            transition: transform 0.3s ease;
        }
        
        #chat-toggle:hover {
            transform: scale(1.1);
        }
        
        #chat-toggle i {
            font-size: 24px;
        }
        
        #chatbot-container {
            position: fixed;
            bottom: 90px;
            right: 20px;
            width: 350px;
            height: 500px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            display: flex;
            flex-direction: column;
            overflow: hidden;
            z-index: 1000;
            transition: all 0.3s ease;
        }
        
        .chatbot-hidden {
            opacity: 0;
            visibility: hidden;
            transform: translateY(20px);
        }
        
        #chat-header {
            padding: 15px;
            background-color: var(--primary-color);
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .chat-title {
            display: flex;
            align-items: center;
            font-weight: bold;
        }
        
        .chat-title i {
            margin-right: 10px;
            font-size: 18px;
        }
        
        #chat-close {
            background: none;
            border: none;
            color: white;
            cursor: pointer;
            font-size: 16px;
        }
        
        #chat-messages {
            flex: 1;
            padding: 15px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .chat-message {
            max-width: 80%;
            padding: 10px 15px;
            border-radius: 18px;
            line-height: 1.4;
            word-wrap: break-word;
        }
        
        .bot-message {
            background-color: #f0f0f0;
            align-self: flex-start;
            border-bottom-left-radius: 5px;
        }
        
        .user-message {
            background-color: var(--primary-color);
            color: white;
            align-self: flex-end;
            border-bottom-right-radius: 5px;
        }
        
        .destination-card-mini {
            width: 100%;
            background-color: white;
            border: 1px solid #eee;
            border-radius: 8px;
            margin-bottom: 10px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        .destination-card-mini img {
            width: 100%;
            height: 120px;
            object-fit: cover;
        }
        
        .destination-card-mini-content {
            padding: 10px;
        }
        
        .destination-card-mini h4 {
            margin: 0 0 5px 0;
            font-size: 16px;
        }
        
        .destination-card-mini-price {
            font-weight: bold;
            color: var(--primary-color);
        }
        
        .destination-card-mini-link {
            display: inline-block;
            margin-top: 5px;
            font-size: 14px;
        }
        
        #chat-input-area {
            padding: 15px;
            display: flex;
            border-top: 1px solid #eee;
        }
        
        #chat-input {
            flex: 1;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 20px;
            outline: none;
        }
        
        #chat-input:focus {
            border-color: var(--primary-color);
        }
        
        #chat-send {
            background: var(--primary-color);
            color: white;
            border: none;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-left: 10px;
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .typing-indicator {
            display: flex;
            align-items: center;
            gap: 5px;
            padding: 10px 15px;
            background-color: #f0f0f0;
            border-radius: 18px;
            align-self: flex-start;
            border-bottom-left-radius: 5px;
            max-width: 80%;
        }
        
        .typing-indicator span {
            width: 8px;
            height: 8px;
            background-color: #888;
            border-radius: 50%;
            animation: typing-dot 1.4s infinite ease-in-out both;
        }
        
        .typing-indicator span:nth-child(1) {
            animation-delay: 0s;
        }
        
        .typing-indicator span:nth-child(2) {
            animation-delay: 0.2s;
        }
        
        .typing-indicator span:nth-child(3) {
            animation-delay: 0.4s;
        }
        
        @keyframes typing-dot {
            0%, 80%, 100% { 
                transform: scale(0.7);
                opacity: 0.5;
            }
            40% { 
                transform: scale(1);
                opacity: 1;
            }
        }
        
        @media (max-width: 576px) {
            #chatbot-container {
                width: calc(100% - 40px);
                height: 60vh;
            }
        }
    `;
    document.head.appendChild(styleSheet);
}

// Toggle chatbot visibility
function toggleChatbot(show) {
    const chatbotContainer = document.getElementById('chatbot-container');
    
    if (show === undefined) {
        show = chatbotContainer.classList.contains('chatbot-hidden');
    }
    
    if (show) {
        chatbotContainer.classList.remove('chatbot-hidden');
        chatbotState.active = true;
        
        // Send welcome message if this is the first time opening
        const chatMessages = document.getElementById('chat-messages');
        if (chatMessages.children.length === 0) {
            setTimeout(() => {
                addBotMessage(botResponses.welcome);
                chatbotState.waitingForBudget = true;
            }, 500);
        }
    } else {
        chatbotContainer.classList.add('chatbot-hidden');
        chatbotState.active = false;
    }
}

// Send user message
function sendUserMessage() {
    const chatInput = document.getElementById('chat-input');
    const message = chatInput.value.trim();
    
    if (message === '') return;
    
    // Add user message to chat
    addUserMessage(message);
    
    // Clear input field
    chatInput.value = '';
    
    // Process user message
    processUserMessage(message);
}

// Show typing indicator
function showTypingIndicator() {
    const chatMessages = document.getElementById('chat-messages');
    const indicator = document.createElement('div');
    indicator.id = 'typing-indicator';
    indicator.className = 'typing-indicator';
    indicator.innerHTML = '<span></span><span></span><span></span>';
    
    chatMessages.appendChild(indicator);
    scrollToBottom();
    
    return indicator;
}

// Remove typing indicator
function removeTypingIndicator() {
    const indicator = document.getElementById('typing-indicator');
    if (indicator) {
        indicator.remove();
    }
}

// Add a bot message to the chat
function addBotMessage(message) {
    const chatMessages = document.getElementById('chat-messages');
    const messageElement = document.createElement('div');
    messageElement.classList.add('chat-message', 'bot-message');
    messageElement.textContent = message;
    
    chatMessages.appendChild(messageElement);
    scrollToBottom();
}

// Add a user message to the chat
function addUserMessage(message) {
    const chatMessages = document.getElementById('chat-messages');
    const messageElement = document.createElement('div');
    messageElement.classList.add('chat-message', 'user-message');
    messageElement.textContent = message;
    
    chatMessages.appendChild(messageElement);
    scrollToBottom();
}

// Add destination cards to the chat
function addDestinationCards(destinations) {
    const chatMessages = document.getElementById('chat-messages');
    const containerElement = document.createElement('div');
    containerElement.classList.add('chat-message', 'bot-message');
    
    let content = '<div class="destinations-container">';
    
    destinations.forEach(destination => {
        // Format price with correct decimal places
        const price = parseFloat(destination.price).toFixed(2);
        
        content += `
            <div class="destination-card-mini">
                <img src="${destination.image_url}" alt="${destination.name}">
                <div class="destination-card-mini-content">
                    <h4>${destination.name}</h4>
                    <div class="destination-card-mini-price">$${price}</div>
                    <a href="/place_detail.html?name=${encodeURIComponent(destination.name)}" 
                       class="destination-card-mini-link">View Details</a>
                </div>
            </div>
        `;
    });
    
    content += '</div>';
    containerElement.innerHTML = content;
    
    chatMessages.appendChild(containerElement);
    scrollToBottom();
}

// Process user message and generate appropriate response
function processUserMessage(message) {
    // Show typing indicator
    const typingIndicator = showTypingIndicator();
    
    // Simulate typing delay
    setTimeout(() => {
        // Remove typing indicator
        removeTypingIndicator();
        
        if (chatbotState.waitingForBudget) {
            processBudgetInput(message);
        } else if (message.toLowerCase().includes('budget') || message.toLowerCase().includes('price')) {
            chatbotState.waitingForBudget = true;
            addBotMessage("What's your travel budget? (in USD)");
        } else if (message.toLowerCase().includes('hello') || message.toLowerCase().includes('hi')) {
            addBotMessage(botResponses.welcome);
            chatbotState.waitingForBudget = true;
        } else if (message.toLowerCase().includes('thank')) {
            addBotMessage(botResponses.goodbye);
        } else if (message.toLowerCase().includes('help')) {
            addBotMessage(botResponses.help);
        } else if (message.toLowerCase().includes('more') && chatbotState.suggestedDestinations.length > 0) {
            // User wants more recommendations
            getMoreRecommendations();
        } else {
            addBotMessage(botResponses.dont_understand);
        }
    }, 1000);
}

// Process budget input from user
function processBudgetInput(input) {
    // Remove currency symbols and commas
    const cleanInput = input.replace(/[$,]/g, '');
    const budget = parseFloat(cleanInput);
    
    if (isNaN(budget) || budget <= 0) {
        addBotMessage(botResponses.budget_invalid);
        return;
    }
    
    if (budget < chatbotState.stats.minPrice) {
        const tooLowMsg = botResponses.budget_too_low.replace('$MINPRICE', chatbotState.stats.minPrice.toLocaleString());
        addBotMessage(tooLowMsg);
        return;
    }
    
    // Store budget and confirm
    chatbotState.currentBudget = budget;
    const confirmMessage = botResponses.budget_confirmed.replace('$BUDGET', budget.toLocaleString());
    addBotMessage(confirmMessage);
    
    // Reset waiting state
    chatbotState.waitingForBudget = false;
    
    // Show loading message
    addBotMessage("Searching for destinations in our database... 🔍");
    
    // Get destination recommendations
    getDestinationRecommendations(budget);
}

// Get destination recommendations based on budget from the database
async function getDestinationRecommendations(budget) {
    try {
        // Call the API endpoint that connects to the database
        const response = await fetch(`/api/chatbot/recommendations?budget=${budget}`);
        
        if (!response.ok) {
            throw new Error('Failed to load recommendations');
        }
        
        const data = await response.json();
        const destinations = data.destinations || [];
        
        // Store all recommended destinations
        chatbotState.suggestedDestinations = destinations;
        
        if (destinations.length === 0) {
            addBotMessage(botResponses.no_results);
            return;
        }
        
        // Show top 3 recommendations
        const topRecommendations = destinations.slice(0, 3);
        
        // Add message before recommendations
        addBotMessage(`I found ${destinations.length} destinations within your budget! Here are my top recommendations:`);
        
        // Add destination cards
        addDestinationCards(topRecommendations);
        
        // Remove these destinations from our list
        chatbotState.suggestedDestinations = destinations.slice(3);
        
        // Add follow-up message
        if (destinations.length > 3) {
            addBotMessage("Would you like to see more options? Just ask for 'more destinations'.");
        } else {
            addBotMessage(botResponses.more_help);
        }
        
    } catch (error) {
        console.error('Error getting recommendations:', error);
        addBotMessage(botResponses.error);
    }
}

// Get more destination recommendations
function getMoreRecommendations() {
    if (chatbotState.suggestedDestinations.length === 0) {
        addBotMessage("I've already shown you all the destinations that match your budget.");
        return;
    }
    
    // Get the next 3 destinations (or fewer if less than 3 remaining)
    const nextBatch = Math.min(3, chatbotState.suggestedDestinations.length);
    const nextRecommendations = chatbotState.suggestedDestinations.slice(0, nextBatch);
    
    // Update the remaining destinations
    chatbotState.suggestedDestinations = chatbotState.suggestedDestinations.slice(nextBatch);
    
    // Add message
    addBotMessage("Here are more destinations within your budget:");
    
    // Add destination cards
    addDestinationCards(nextRecommendations);
    
    // Add follow-up message
    if (chatbotState.suggestedDestinations.length > 0) {
        addBotMessage("Would you like to see more options? Just ask for 'more destinations'.");
    } else {
        addBotMessage(botResponses.more_help);
    }
}

// Scroll chat messages to bottom
function scrollToBottom() {
    const chatMessages = document.getElementById('chat-messages');
    chatMessages.scrollTop = chatMessages.scrollHeight;
}