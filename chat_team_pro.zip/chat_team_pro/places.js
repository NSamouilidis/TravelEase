
const allDestinations = [
  {
    name: "Santorini, Greece",
    image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80",
    price: "$799"
  },
  {
    name: "Kyoto, Japan",
    image: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?auto=format&fit=crop&w=800&q=80",
    price: "$899"
  },
  {
    name: "Paris, France",
    image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?auto=format&fit=crop&w=800&q=80",
    price: "$999"
  },
  {
    name: "Dubai, UAE",
    image: "https://images.unsplash.com/photo-1508609349937-5ec4ae374ebf?auto=format&fit=crop&w=800&q=80",
    price: "$899"
  },
  {
    name: "Bali, Indonesia",
    image: "https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=crop&w=800&q=80",
    price: "$849"
  },
  {
    name: "Rome, Italy",
    image: "https://images.unsplash.com/photo-1528909514045-2fa4ac7a08ba?auto=format&fit=crop&w=800&q=80",
    price: "$950"
  }
];

const container = document.getElementById("allDestinations");
const searchInput = document.getElementById("searchInput");

function displayDestinations(destinations) {
  container.innerHTML = "";
  destinations.forEach(place => {
    const card = document.createElement("div");
    card.className = "destination-card";
    card.innerHTML = `
      <a href="place_detail.html?name=${encodeURIComponent(place.name)}">
        <img src="${place.image}" alt="${place.name}" />
        <h4>${place.name}</h4>
        <p>From ${place.price}</p>
      </a>
    `;
    container.appendChild(card);
  });
}

displayDestinations(allDestinations);

searchInput.addEventListener("input", () => {
  const searchTerm = searchInput.value.toLowerCase();
  const filtered = allDestinations.filter(place =>
    place.name.toLowerCase().includes(searchTerm)
  );
  displayDestinations(filtered);
});
