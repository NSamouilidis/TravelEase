// main.js

const destinations = [
    {
      name: "Santorini, Greece",
      image: "https://images.unsplash.com/photo-1507525428034-b723cf961d3e",
      price: "$799"
    },
    {
      name: "Kyoto, Japan",
      image: "https://images.unsplash.com/photo-1568605114967-8130f3a36994",
      price: "$899"
    },
    {
      name: "Paris, France",
      image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34",
      price: "$999"
    }
  ];
  
  const grid = document.getElementById("destinationGrid");
  destinations.forEach(place => {
    const card = document.createElement("div");
    card.className = "destination-card";
    card.innerHTML = `
      <img src="${place.image}" alt="${place.name}" />
      <h4>${place.name}</h4>
      <p>From ${place.price}</p>
    `;
    grid.appendChild(card);
  });
  
  function handleUserInput() {
    const input = document.getElementById("userInput").value;
    const response = `Looking for vacations under ${input}... coming soon!`;
    const chatBox = document.getElementById("chatBox");
    const userMsg = `<div class='message user'>${input}</div>`;
    const botMsg = `<div class='message bot'>${response}</div>`;
    chatBox.innerHTML += userMsg + botMsg;
    chatBox.scrollTop = chatBox.scrollHeight;
  }