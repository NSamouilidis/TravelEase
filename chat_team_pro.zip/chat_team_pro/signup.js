document.getElementById('registerBtn').addEventListener('click', async (event) => {
    event.preventDefault(); // 🛑 prevent form reload before anything else

    const username = document.getElementById('signup-username').value;
    const email = document.getElementById('signup-email').value;
    const password = document.getElementById('signup-password').value;

    const res = await fetch('http://localhost:3000/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, email, password })
    });

    const data = await res.json();

    if (data.message) {
        alert(`✅ ${data.message}\\nWelcome, ${username}!`);

        // Optional: store data in localStorage
        localStorage.setItem('user', JSON.stringify({ username, email }));

        // Switch to login.html
        window.location.href = 'login.html';
    } else {
        alert(`❌ ${data.error}`);
    }
});
