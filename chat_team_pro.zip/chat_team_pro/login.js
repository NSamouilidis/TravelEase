document.getElementById('loginBtn').addEventListener('click', async (event) => {
    event.preventDefault(); // Stop form from reloading

    const username = document.getElementById('login-username').value;
    const password = document.getElementById('login-password').value;

    const res = await fetch('http://localhost:3000/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
    });

    const data = await res.json();

    if (data.user) {
        alert(`✅ Welcome back, ${data.user.username}!`);
        localStorage.setItem('user', JSON.stringify(data.user));
        window.location.href = 'profile.html';
    } else {
        alert(`❌ ${data.error}`);
    }
});
